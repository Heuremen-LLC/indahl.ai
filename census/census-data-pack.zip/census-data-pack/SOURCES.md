# CENSUS Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-11T15:35:42Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| U.S. Census Bureau Economic Indicators Time Series API (new residential sales, new residential construction, monthly retail trade) | https://www.census.gov/data/developers/data-sets/eits.html | U.S. government work, public domain (17 U.S.C. 105). This product uses the Census Bureau Data API but is not endorsed or certified by the Census Bureau | 2026-11-11T15:35:42Z |
| Federal Reserve Bank of St. Louis ALFRED archival series HSN1F, HOUST, PERMIT, COMPUTSA, RSAFS | https://alfred.stlouisfed.org/ | Census Bureau and HUD data, public domain, citation requested | 2026-11-11T15:35:42Z |
