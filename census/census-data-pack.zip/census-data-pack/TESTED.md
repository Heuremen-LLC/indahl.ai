# CENSUS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 15:45 UTC and checked against the live feed at https://indahl.ai/census/live.json.

- holds: census_summary.csv: 1869 rows, one per value of the live feed (1869)
- holds: census_outcomes.csv: 117 rows, the live feed holds 117 results, outcome, n, lo and hi equal on every row
- holds: census_summary.json: byte for byte the live feed (sha256 ad25736426e1f848)
- holds: page headline "117 of 117": 117 is in the pack
- holds: page headline "117 of 117": 117 is in the pack
- holds: rows.csv: 5031 rows, the live feed counts 5031

TESTED 2026-11-11 15:45 UTC: 6 checks, every one holds.
