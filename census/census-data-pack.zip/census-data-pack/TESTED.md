# CENSUS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 16:20 UTC and checked against the live feed at https://indahl.ai/census/live.json.

- holds: census_summary.csv: 2148 rows, one per value of the live feed (2148)
- holds: census_outcomes.csv: 117 rows, the live feed holds 117 results, outcome, n, lo and hi equal on every row
- holds: census_summary.json: byte for byte the live feed (sha256 e135ee695f7ae801)
- holds: page headline "117 of 117": 117 is in the pack
- holds: page headline "117 of 117": 117 is in the pack
- holds: rows.csv: 5031 rows, the live feed counts 5031

TESTED 2026-11-12 16:20 UTC: 6 checks, every one holds.
