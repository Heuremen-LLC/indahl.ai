# ARXIVDRIFT Data Pack

Heuremen LLC · https://indahl.ai/arxivdrift

As of 14 Nov 2026 13:05, the time stamped on the desk's feed when this pack was built.

## The question

Studies read, then revised. The page states it in full at https://indahl.ai/arxivdrift.

## The ruler

Unchanged: the version we read is the newest. Revised, nothing changed: a later version exists with the same title, wording and abstract numbers. Revised wording: same numbers, different title or abstract. Revised numbers: the numbers in the abstract differ. Withdrawn: the paper itself. Source: the arXiv API.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/arxivdrift_outcomes.csv holds 5 rows, each with an interval and no outcome word.

## Files

- results/arxivdrift_summary.json: the feed as served at https://indahl.ai/arxivdrift/live.json when this pack was built.
- results/arxivdrift_summary.csv: the same file flattened to one row per value, with its path.
- results/arxivdrift_outcomes.json and results/arxivdrift_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/rows.json and results/rows.csv: one row per item the desk reads (1590 rows).
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served and the per-item rows, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
