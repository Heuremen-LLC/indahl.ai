# ARXIVDRIFT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 14:51 UTC and checked against the live feed at https://indahl.ai/arxivdrift/live.json.

- holds: arxivdrift_summary.csv: 108 rows, one per value of the live feed (108)
- holds: arxivdrift_outcomes.csv: 5 rows, the live feed holds 5 results, outcome, n, lo and hi equal on every row
- holds: arxivdrift_summary.json: byte for byte the live feed (sha256 cd8769fd1632744a)
- holds: rows.csv: 1590 rows, the live feed counts 1590

TESTED 2026-11-13 14:51 UTC: 4 checks, every one holds.
