# ARXIVDRIFT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 19:10 UTC and checked against the live feed at https://indahl.ai/arxivdrift/live.json.

- holds: arxivdrift_summary.csv: 80 rows, one per value of the live feed (80)
- holds: arxivdrift_outcomes.csv: 4 rows, the live feed holds 4 results, outcome, n, lo and hi equal on every row
- holds: arxivdrift_summary.json: byte for byte the live feed (sha256 7e8bcc37ee5b8aa7)
- holds: rows.csv: 1590 rows, the live feed counts 1590

TESTED 2026-11-11 19:10 UTC: 4 checks, every one holds.
