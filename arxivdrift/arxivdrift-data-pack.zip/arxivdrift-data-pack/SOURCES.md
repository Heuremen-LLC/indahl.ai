# ARXIVDRIFT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 11 Nov 2026 19:35, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| arXiv API metadata | https://info.arxiv.org/help/api/ | CC0 1.0 for metadata, https://info.arxiv.org/help/license/index.html | 11 Nov 2026 19:35 |
| QIA List and IRIS List | https://indahl.ai/qia/list.json | Heuremen LLC | 11 Nov 2026 19:35 |
