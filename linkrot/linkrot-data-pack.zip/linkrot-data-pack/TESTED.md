# LINKROT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 14:53 UTC and checked against the live feed at https://indahl.ai/linkrot/live.json.

- holds: linkrot_summary.csv: 314 rows, one per value of the live feed (314)
- holds: linkrot_outcomes.csv: 25 rows, the live feed holds 25 results, outcome, n, lo and hi equal on every row
- holds: linkrot_summary.json: byte for byte the live feed (sha256 876caedcbd9c9824)
- holds: page headline "3.3%": 3.3% is in the pack
- holds: rows.csv: 1980 rows, the live feed counts 1980

TESTED 2026-11-11 14:53 UTC: 5 checks, every one holds.
