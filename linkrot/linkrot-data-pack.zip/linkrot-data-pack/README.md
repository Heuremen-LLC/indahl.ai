# LINKROT Data Pack

Heuremen LLC · https://indahl.ai/linkrot

As of 11 Nov 2026 15:41, the time stamped on the desk's feed when this pack was built.

## The question

Stated code links against live. The page states it in full at https://indahl.ai/linkrot.

## The ruler

Above: the rot share has a lower bound above 10 percent. Consistent: the upper bound is below 5 percent. Cannot tell: neither, or fewer than 30 readable links. Thresholds were fixed before the first check. Source: the arXiv API. Addresses from every monthly column page the Wayback Machine holds, gopher, ftp and telnet links left out, read in a random draw. Each cell gives the count and its share of the addresses read in that column, with a Wilson 95% interval in brackets. A column with fewer than 30 addresses read shows counts only. Of the HTTP errors, 118 answered 404 or 410, 16 answered 401, 403 or 429, 2 answered another 4xx status and 2 answered a 5xx status. A 401, 403 or 429 can be a refusal of automated readers rather than a missing page. Columns group addresses by the year of their earliest capture in the Wayback Machine. The last column holds addresses with no capture before the directory closed. Each cell gives the count and its share of the addresses read in that column, with a Wilson 95% interval in brackets. A column with fewer than 30 addresses read shows counts only. 8 of the 1,500 addresses drawn have no column yet, because our checker failed before their earliest capture could be looked up: 8 read as our checker failed. They are read again on the next pass. Of the HTTP errors, 71 answered 401, 403 or 429, 69 answered 404 or 410, 9 answered another 4xx status, 9 ended on a redirect answer (a loop, more than 10 redirects, or a redirect we could not follow) and 8 answered a 5xx status. A 401, 403 or 429 can be a refusal of automated readers rather than a missing page. Only reference sections count. Later RFCs cite other RFCs through the RFC Editor’s own site, so addresses on IETF and IANA hosts are drawn and shown apart. The earliest era holds very few cited addresses. Each cell gives the count and its share of the addresses read in that column, with a Wilson 95% interval in brackets. A column with fewer than 30 addresses read shows counts only. Addresses on one domain tend to live or die together. In the column 2009 to 2017, IETF and IANA hosts, a single registered domain holds 45 of 50 addresses. The table below counts each registered domain once, taking its first address in draw order (defined after the data). Of the HTTP errors, 131 answered 404 or 410, 22 answered 401, 403 or 429, 7 answered another 4xx status and 1 ended on a redirect answer (a loop, more than 10 redirects, or a redirect we could not follow). A 401, 403 or 429 can be a refusal of automated readers rather than a missing page. One address drawn from each document drawn. Federal Register documents published in each era that contain a web address. Each cell gives the count and its share of the addresses read in that column, with a Wilson 95% interval in brackets. A column with fewer than 30 addresses read shows counts only. Documents can share a drawn address. In 1995 to 1996, 150 documents give 93 distinct addresses, and the most frequent address was drawn from 8 of them. In 1997 to 2001, 150 documents give 102 distinct addresses, and the most frequent address was drawn from 19 of them. In 2002 to 2008, 150 documents give 93 distinct addresses, and the most frequent address was drawn from 24 of them. In 2009 to 2017, 150 documents give 89 distinct addresses, and the most frequent address was drawn from 34 of them. So documents are not independent units, and the table below counts each distinct address once (defined after the data). Of the HTTP errors, 173 answered 401, 403 or 429 and 81 answered 404 or 410. A 401, 403 or 429 can be a refusal of automated readers rather than a missing page. A version is dated by the first capture of the newest distinct content the Wayback Machine holds. A page counts as unchanged since that version only when its bytes today equal it. Pages whose bytes differ changed after the archive’s newest version, so they carry no date. The ten-year share is of answering pages the archive holds a history for. The median interval is the distribution-free 95% interval from order statistics. Still due counts addresses with a key beginning 0, 1 or 2 that have no second read yet, mostly because their first good read came in the latest pass. They are read again once three hours have passed since it. The table below gives the changes between the two reads, by pair of states. The first addresses in draw order from each sample, after removing personal pages and personal hosting services. Each is shown as its host only, with the rest of the address shortened, and as text, not as a link. Columns group sites by the year a list first named them. Each cell gives the count and its share of the sites read in that column, with a Wilson 95% interval in brackets. A column with fewer than 30 sites read shows counts only. The frame holds 7,595 sites and 150 have been read so far, in draw order. Readers named boredatwork.com, yourethemannowdog.com, badgerbadgerbadger.com before the list rule was written. None of them comes out of the rule. Sites that do not come out of the rule are read by the same rules in rows marked suggested by readers and are kept out of the rates above. The read in draw order has reached 0 of them so far. Coverage: every Webby winners page for 1997 to 2008, every Yahoo! Picks weekly page, every Cool Site of the Day monthly page from August 1994 to November 2019, and Wikipedia’s list in monthly versions from May 2004 to January 2010 and today. Yahoo! Picks one-day pages for 672 days between November 2004 and January 2008 were not read in this version of the list. Years since the content last changed come from the newest distinct version the Wayback Machine holds. For a site that answers today they count only when today’s page is byte for byte that version. First capture is the earliest 200 capture of the address. Each address is read at http://indahl.<ending>/ with the same states, parking detector and robots.txt rule as the samples above. Years since the content last changed come from the newest distinct version the Wayback Machine holds. For a domain that answers today the years count only when today’s page is byte for byte that version. Registered and expiry come from the registry’s RDAP service. Where a registry offers none, registered reads from DNS delegation, marked DNS, which cannot show an expiry date.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/linkrot_outcomes.csv holds 25 rows: 13 CANNOT_TELL, 12 CONSISTENT.

## Files

- results/linkrot_summary.json: the feed as served at https://indahl.ai/linkrot/live.json when this pack was built.
- results/linkrot_summary.csv: the same file flattened to one row per value, with its path.
- results/linkrot_outcomes.json and results/linkrot_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/rows.json and results/rows.csv: one row per item the desk reads (1980 rows).
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served and the per-item rows, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
