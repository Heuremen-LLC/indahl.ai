# LINKROT Data Pack

Heuremen LLC · https://indahl.ai/linkrot

As of 10 Nov 2026 13:33, the time stamped on the desk's feed when this pack was built.

## The question

Stated code links against live. The page states it in full at https://indahl.ai/linkrot.

## The ruler

Above: the rot share has a lower bound above 10 percent. Consistent: the upper bound is below 5 percent. Cannot tell: neither, or fewer than 30 readable links. Thresholds were fixed before the first check. Source: the arXiv API.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/linkrot_outcomes.csv holds 25 rows: 13 CANNOT_TELL, 12 CONSISTENT.

## Files

- results/linkrot_summary.json: the feed as served at https://indahl.ai/linkrot/live.json when this pack was built.
- results/linkrot_summary.csv: the same file flattened to one row per value, with its path.
- results/linkrot_outcomes.json and results/linkrot_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/rows.json and results/rows.csv: one row per item the desk reads (1980 rows).
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served and the per-item rows, with credit to each source in NOTICE.txt.
