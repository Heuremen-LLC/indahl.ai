# LINKROT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 12 Nov 2026 16:29, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| arXiv API abstracts and comments (links) | https://info.arxiv.org/help/api/ | CC0 1.0 for metadata | 12 Nov 2026 16:29 |
| Link targets read over HTTP | https://indahl.ai/linkrot | our own measurements | 12 Nov 2026 16:29 |
