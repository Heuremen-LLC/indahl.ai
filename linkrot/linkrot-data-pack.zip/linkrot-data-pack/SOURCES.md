# LINKROT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 10 Nov 2026 13:33, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| arXiv API abstracts and comments (links) | https://info.arxiv.org/help/api/ | CC0 1.0 for metadata | 10 Nov 2026 13:33 |
| Link targets read over HTTP | https://indahl.ai/linkrot | our own measurements | 10 Nov 2026 13:33 |
