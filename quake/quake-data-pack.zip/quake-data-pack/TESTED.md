# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-14 12:47 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4102 rows, one per value of the live feed (4102)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 de39ec5ce6f96839)
- holds: page headline "30,849 of 32,054": 30,849 is in the pack
- holds: page headline "30,849 of 32,054": 32,054 is in the pack

TESTED 2026-11-14 12:47 UTC: 5 checks, every one holds.
