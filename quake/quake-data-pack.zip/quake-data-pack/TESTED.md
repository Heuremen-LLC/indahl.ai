# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 00:08 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 3898 rows, one per value of the live feed (3898)
- holds: quake_outcomes.csv: 86 rows, the live feed holds 86 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 015645dc876be782)
- holds: page headline "30,650 of 31,848": 30,650 is in the pack
- holds: page headline "30,650 of 31,848": 31,848 is in the pack

TESTED 2026-11-12 00:08 UTC: 5 checks, every one holds.
