# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 16:35 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 3898 rows, one per value of the live feed (3898)
- holds: quake_outcomes.csv: 86 rows, the live feed holds 86 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 e6fe2f467158072b)
- holds: page headline "30,630 of 31,828": 30,630 is in the pack
- holds: page headline "30,630 of 31,828": 31,828 is in the pack

TESTED 2026-11-11 16:35 UTC: 5 checks, every one holds.
