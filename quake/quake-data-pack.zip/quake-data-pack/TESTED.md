# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 01:21 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 3898 rows, one per value of the live feed (3898)
- holds: quake_outcomes.csv: 86 rows, the live feed holds 86 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 d31063fb6d9f5e6f)
- holds: page headline "30,655 of 31,853": 30,655 is in the pack
- holds: page headline "30,655 of 31,853": 31,853 is in the pack

TESTED 2026-11-12 01:21 UTC: 5 checks, every one holds.
