# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 16:29 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 3778 rows, one per value of the live feed (3778)
- holds: quake_outcomes.csv: 76 rows, the live feed holds 76 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 c2d96cba09887482)
- holds: page headline "30,761 of 31,950": 30,761 is in the pack
- holds: page headline "30,761 of 31,950": 31,950 is in the pack

TESTED 2026-11-10 16:29 UTC: 5 checks, every one holds.
