# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 16:46 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 4102 rows, one per value of the live feed (4102)
- holds: quake_outcomes.csv: 87 rows, the live feed holds 87 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 e50cc631379b76ce)
- holds: page headline "30,707 of 31,907": 30,707 is in the pack
- holds: page headline "30,707 of 31,907": 31,907 is in the pack

TESTED 2026-11-12 16:46 UTC: 5 checks, every one holds.
