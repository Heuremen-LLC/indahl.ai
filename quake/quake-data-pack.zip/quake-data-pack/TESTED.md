# QUAKE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 12:54 UTC and checked against the live feed at https://indahl.ai/quake/live.json.

- holds: quake_summary.csv: 3908 rows, one per value of the live feed (3908)
- holds: quake_outcomes.csv: 86 rows, the live feed holds 86 results, outcome, n, lo and hi equal on every row
- holds: quake_summary.json: byte for byte the live feed (sha256 48e0908fc545a6d2)
- holds: page headline "30,683 of 31,883": 30,683 is in the pack
- holds: page headline "30,683 of 31,883": 31,883 is in the pack

TESTED 2026-11-12 12:54 UTC: 5 checks, every one holds.
