# QUAKE Data Pack

Heuremen LLC · https://indahl.ai/quake

As of 2026-11-14T12:09:28Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated aftershock odds against the aftershocks that followed. The page states it in full at https://indahl.ai/quake.

## The ruler

One row is one forecast version, one window and one magnitude. Reading against the stated 95 percent: below if the upper bound is under 95 percent, above if the lower bound is over 95 percent, consistent if the interval lies within 92.5 to 97.5 percent, otherwise cannot tell with the reason STRADDLES_EDGE. Fewer than 30 rows or fewer than 10 separate groups of nearby sequences is cannot tell with the reason TOO_WIDE_TO_RESOLVE. A cell with no rows or no interval is cannot tell with the reason NO_INTERVAL_FORMABLE. Edges are closed, so an interval end equal to a stated figure is neither above nor below it. No size that matters is named for these cells, so the check for an interval that holds both zero and a size that matters is not applied. A range of 0 to 0 is a statement that none is likely, and a single event breaks it. Most rows at M5 and above have a range of 0 to 0, and those rows are inside unless one such earthquake happens. Without them, M3 and above holds 18,271 of 19,240 inside (95.0 percent, interval 92.1 to 97.3 percent, cannot tell (STRADDLES_EDGE)). Every magnitude and window together. Reading: above if the lower bound is over the mean stated chance, below if the upper bound is under it, consistent if the whole interval lies within a tolerance of it, otherwise cannot tell with the reason STRADDLES_EDGE. Fewer than 30 rows or 10 groups is cannot tell with the reason TOO_WIDE_TO_RESOLVE. The tolerance is 5 points, or half the stated chance or half its complement when that is smaller, and never under 1 point. The chance of an earthquake as large as the mainshock is read on its own: 63 of 32,034 windows saw one against a mean stated chance of 0.4 percent, and the reading is consistent.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/quake_outcomes.csv holds 87 rows: 33 ABOVE, 31 BELOW, 18 CANNOT_TELL, 4 CONSISTENT.

## Files

- results/quake_summary.json: the feed as served at https://indahl.ai/quake/live.json when this pack was built.
- results/quake_summary.csv: the same file flattened to one row per value, with its path.
- results/quake_outcomes.json and results/quake_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, ATLAS Desk Packs, Zenodo, doi:10.5281/zenodo.24118626

https://doi.org/10.5281/zenodo.24118626

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
