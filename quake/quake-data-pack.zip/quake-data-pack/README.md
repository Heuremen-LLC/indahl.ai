# QUAKE Data Pack

Heuremen LLC · https://indahl.ai/quake

As of 2026-11-10T15:24:55Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated aftershock odds against the aftershocks that followed. The page states it in full at https://indahl.ai/quake.

## The ruler

One row is one forecast version, one window and one magnitude. Reading against the stated 95 percent: below if the upper bound is under 95 percent, above if the lower bound is over 95 percent, consistent if the interval lies within 92.5 to 97.5 percent, otherwise cannot tell. Fewer than 30 rows or fewer than 10 separate groups of nearby sequences is cannot tell. A range of 0 to 0 is a statement that none is likely, and a single event breaks it. Most rows at M5 and above have a range of 0 to 0, and those rows are inside unless one such earthquake happens. Without them, M3 and above holds 18,171 of 19,131 inside (95.0 percent, interval 92.1 to 97.3 percent, cannot tell). Every magnitude and window together. Reading: above if the lower bound is over the mean stated chance, below if the upper bound is under it, consistent if the whole interval lies within a tolerance of it, otherwise cannot tell. The tolerance is 5 points, or half the stated chance or half its complement when that is smaller, and never under 1 point. The chance of an earthquake as large as the mainshock is read on its own: 56 of 31,950 windows saw one against a mean stated chance of 0.4 percent, and the reading is consistent.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/quake_outcomes.csv holds 76 rows: 30 BELOW, 26 ABOVE, 16 CANNOT_TELL, 4 CONSISTENT.

## Files

- results/quake_summary.json: the feed as served at https://indahl.ai/quake/live.json when this pack was built.
- results/quake_summary.csv: the same file flattened to one row per value, with its path.
- results/quake_outcomes.json and results/quake_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.
