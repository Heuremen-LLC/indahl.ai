# AIRLINE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 22:09 UTC and checked against the live feed at https://indahl.ai/airline/live.json.

- holds: airline_summary.csv: 443 rows, one per value of the live feed (443)
- holds: airline_outcomes.csv: 28 rows, the live feed holds 28 results, outcome, n, lo and hi equal on every row
- holds: airline_summary.json: byte for byte the live feed (sha256 3e2b0cc6d70b369b)
- holds: page headline "5 of 13": 5 is in the pack
- holds: page headline "5 of 13": 13 is in the pack

TESTED 2026-11-12 22:09 UTC: 5 checks, every one holds.
