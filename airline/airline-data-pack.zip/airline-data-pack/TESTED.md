# AIRLINE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 16:27 UTC and checked against the live feed at https://indahl.ai/airline/live.json.

- holds: airline_summary.csv: 417 rows, one per value of the live feed (417)
- holds: airline_outcomes.csv: 28 rows, the live feed holds 28 results, outcome, n, lo and hi equal on every row
- holds: airline_summary.json: byte for byte the live feed (sha256 13eb53c5a9c97122)
- holds: page headline "5 of 13": 5 is in the pack
- holds: page headline "5 of 13": 13 is in the pack

TESTED 2026-11-13 16:27 UTC: 5 checks, every one holds.
