# AIRLINE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-10-29T14:54Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| BTS Reporting Carrier On-Time Performance | https://www.transtats.bts.gov/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-10-29T14:54Z |
| FAA NAS Status airport feed | https://nasstatus.faa.gov/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-10-29T14:54Z |
