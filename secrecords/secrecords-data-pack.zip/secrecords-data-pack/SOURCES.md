# SECRECORDS Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 14 Nov 2026 00:27, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Tranco list | https://tranco-list.eu/ | Tranco terms, built from inputs that include CC BY-NC and share-alike data | 14 Nov 2026 00:27 |
| HTTPS headers and DNS records of each domain | https://indahl.ai/secrecords | public protocol facts, our own reads | 14 Nov 2026 00:27 |
