# SECRECORDS Data Pack

Heuremen LLC · https://indahl.ai/secrecords

As of 12 Nov 2026 12:47, the time stamped on the desk's feed when this pack was built.

## The question

Security records against their own rules. The page states it in full at https://indahl.ai/secrecords.

## The ruler

Agree: the header on the base domain's own response has a max-age of at least one year and includeSubDomains, or the record needs ten lookups or fewer. Disagree: it does not. Above: the lower end of the 95 percent interval of the disagreement share is above 0.10. Consistent: the upper end is below 0.05. Otherwise, and with fewer than 30 comparable domains, cannot tell. The three descriptive rows carry no claim and no outcome. Sources: each domain's own HTTPS response (redirects are not followed), and Cloudflare's DNS over HTTPS service. Domain list: Tranco.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/secrecords_outcomes.csv holds 2 rows: 1 CANNOT_TELL, 1 CONSISTENT.

## Files

- results/secrecords_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/secrecords_summary.csv: the same file flattened to one row per value, with its path.
- results/secrecords_outcomes.json and results/secrecords_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because the Tranco list draws on a non-commercial input and a share-alike input.

## Cite

Heuremen LLC, ATLAS Data Pack, Zenodo, doi:10.5281/zenodo.23874305

https://doi.org/10.5281/zenodo.23874305

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
