# SECRECORDS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 13:44 UTC and checked against the live feed at https://indahl.ai/secrecords/live.json.

- holds: secrecords_summary.csv: 109 rows, one per value of the live feed (109)
- holds: secrecords_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: page headline "13%": 13% is in the pack

TESTED 2026-11-12 13:44 UTC: 3 checks, every one holds.
