# SECRECORDS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 22:10 UTC and checked against the live feed at https://indahl.ai/secrecords/live.json.

- holds: secrecords_summary.csv: 120 rows, one per value of the live feed (120)
- holds: secrecords_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: page headline "13%": 13% is in the pack

TESTED 2026-11-12 22:10 UTC: 3 checks, every one holds.
