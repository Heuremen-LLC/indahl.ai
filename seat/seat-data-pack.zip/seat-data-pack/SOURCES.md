# SEAT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 11 Nov 2026 15:59, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Probes of indahl.ai from the GitHub runner network | https://github.com/Heuremen-LLC/nodes | our own measurements | 11 Nov 2026 15:59 |
