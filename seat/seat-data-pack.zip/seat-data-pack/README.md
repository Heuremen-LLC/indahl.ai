# SEAT Data Pack

Heuremen LLC · https://indahl.ai/seat

As of 12 Nov 2026 01:34, the time stamped on the desk's feed when this pack was built.

## The question

An outside seat reads our own pages. The page states it in full at https://indahl.ai/seat.

## The ruler

An incident is a run of consecutive probes that each had a drifting page, a feed past its limit or a broken chain, however many probes it lasts. Consistent: none of the last 24 probes had an incident. Above: three or more incidents. Anything in between, fewer than 24 probes, or a newest probe more than three hours old reads cannot tell. The table of incidents names each one, with its first and last probe and what the probes saw. The probes are triggered by our scheduler, not by a timer. Code and every probe: the nodes repository, linked below.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/seat_outcomes.csv holds 1 row: 1 CONSISTENT.

## Files

- results/seat_summary.json: the feed as served at https://indahl.ai/seat/live.json when this pack was built.
- results/seat_summary.csv: the same file flattened to one row per value, with its path.
- results/seat_outcomes.json and results/seat_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, ATLAS Data Pack, Zenodo, doi:10.5281/zenodo.23874305

https://doi.org/10.5281/zenodo.23874305

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
