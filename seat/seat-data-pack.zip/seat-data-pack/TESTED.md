# SEAT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 14:32 UTC and checked against the live feed at https://indahl.ai/seat/live.json.

- holds: seat_summary.csv: 232 rows, one per value of the live feed (232)
- holds: seat_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: seat_summary.json: byte for byte the live feed (sha256 ba21b2e83aa0d246)

TESTED 2026-11-11 14:32 UTC: 3 checks, every one holds.
