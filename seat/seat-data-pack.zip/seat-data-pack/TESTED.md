# SEAT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 16:34 UTC and checked against the live feed at https://indahl.ai/seat/live.json.

- holds: seat_summary.csv: 236 rows, one per value of the live feed (236)
- holds: seat_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: seat_summary.json: byte for byte the live feed (sha256 9ed12997e7b81b71)

TESTED 2026-11-11 16:34 UTC: 3 checks, every one holds.
