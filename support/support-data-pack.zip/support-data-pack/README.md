# SUPPORT Data Pack

Heuremen LLC · https://indahl.ai/support

As of 14 Nov 2026 02:16, the time stamped on the desk's feed when this pack was built.

## The question

Stated support windows against release activity. The page states it in full at https://indahl.ai/support.

## The ruler

Supported, as the plan states it: the stated end of life is in the future or not stated, the stated support end, if any, has not passed, and the cycle was released more than 400 days ago. Cycles with no latest release date, no release date, an end of life stated only as passed, or a support end that has passed are counted apart and not tested. Until 10 November 2026 the code still tested a cycle whose support end had passed when its end of life was in the future. The plan wins, and the count under the old rule is shown once beside the first row (plan addendum 3). The dates are as endoflife.date gives them and are not checked against the vendors. In the list of unreleased cycles, False in the end-of-life column means no end of life is stated. Outcome rule, moved to Standards 2.0 by a plan addendum on 12 November 2026: above means the lower end of the 95 percent interval of the unreleased share is at or above 5 percent. Consistent means the whole interval lies below 5 percent. Anything else is cannot tell, with a reason beside it. A share of 10 percent is the size that matters, so an interval that holds both zero and 10 percent reads TOO_WIDE_TO_RESOLVE, and so does any row with fewer than 30 cycles or products. An interval that overlaps the 5 percent edge reads STRADDLES_EDGE. Outcomes recorded before that date stand under the rule they named. REQ-13 beside each headline row gives the products that returned nothing and the share of cannot tell by reason. The first row is judged on its interval over products. The Wilson columns, which treat cycles as independent, are shown beside it and are not what the outcome uses.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/support_outcomes.csv holds 44 rows: 41 CANNOT_TELL, 3 ABOVE.

## Files

- results/support_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/support_summary.csv: the same file flattened to one row per value, with its path.
- results/support_outcomes.json and results/support_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because the endoflife.date licence was not confirmed for this pack.

## Cite

Heuremen LLC, ATLAS Data Pack, Zenodo, doi:10.5281/zenodo.23874305

https://doi.org/10.5281/zenodo.23874305

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
