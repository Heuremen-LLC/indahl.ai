# SUPPORT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 13 Nov 2026 13:56, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| endoflife.date API | https://endoflife.date/docs/api | endoflife.date terms | 13 Nov 2026 13:56 |
