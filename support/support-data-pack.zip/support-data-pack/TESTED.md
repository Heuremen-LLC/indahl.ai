# SUPPORT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 13:36 UTC and checked against the live feed at https://indahl.ai/support/live.json.

- holds: support_summary.csv: 746 rows, one per value of the live feed (746)
- holds: support_outcomes.csv: 58 rows, the live feed holds 58 results, outcome, n, lo and hi equal on every row
- holds: page headline "25%": 25% is in the pack

TESTED 2026-11-10 13:36 UTC: 3 checks, every one holds.
