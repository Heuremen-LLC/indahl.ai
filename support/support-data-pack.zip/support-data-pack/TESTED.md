# SUPPORT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 16:40 UTC and checked against the live feed at https://indahl.ai/support/live.json.

- holds: support_summary.csv: 604 rows, one per value of the live feed (604)
- holds: support_outcomes.csv: 45 rows, the live feed holds 45 results, outcome, n, lo and hi equal on every row
- holds: page headline "24%": 24% is in the pack

TESTED 2026-11-11 16:40 UTC: 3 checks, every one holds.
