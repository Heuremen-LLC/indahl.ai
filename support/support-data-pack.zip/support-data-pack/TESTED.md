# SUPPORT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 16:04 UTC and checked against the live feed at https://indahl.ai/support/live.json.

- holds: support_summary.csv: 651 rows, one per value of the live feed (651)
- holds: support_outcomes.csv: 44 rows, the live feed holds 44 results, outcome, n, lo and hi equal on every row
- holds: page headline "24%": 24% is in the pack

TESTED 2026-11-12 16:04 UTC: 3 checks, every one holds.
