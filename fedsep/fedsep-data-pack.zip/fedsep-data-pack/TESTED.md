# FEDSEP Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 13:44 UTC and checked against the live feed at https://indahl.ai/fedsep/live.json.

- holds: fedsep_summary.csv: 212 rows, one per value of the live feed (212)
- holds: fedsep_outcomes.csv: 12 rows, the live feed holds 12 results, outcome, n, lo and hi equal on every row
- holds: fedsep_summary.json: byte for byte the live feed (sha256 a41549a9f9ced13b)
- holds: page headline "10 of 37": 10 is in the pack
- holds: page headline "10 of 37": 37 is in the pack
- holds: rows.csv: 78 rows, the live feed counts 78

TESTED 2026-11-10 13:44 UTC: 6 checks, every one holds.
