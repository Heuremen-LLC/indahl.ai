# FEDSEP Data Pack

Heuremen LLC · https://indahl.ai/fedsep

As of 13 Nov 2026 05:38, the time stamped on the desk's feed when this pack was built.

## The question

The Fed's stated ranges against outcomes. The page states it in full at https://indahl.ai/fedsep.

## The ruler

Outside: the outcome differs from the median by more than the stated range for that variable and horizon. Above: the lower end of the interval is above 0.30. Below: the upper end is below 0.30, the share a 70 percent range would leave outside. Otherwise cannot tell (STRADDLES_EDGE). The figure 0.30 has no tolerance, so no row reads consistent (plan addendum of 12 November 2026). Until then the plan read consistent when 0.30 sat inside an interval no wider than 0.45, and the readings recorded under that rule stand. The federal funds rate is scored against the fourth-quarter average, as fixed in the plan, with a year-end row defined after the first read. Outcomes are the latest values from FRED. Projections: the Federal Reserve Board.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/fedsep_outcomes.csv holds 12 rows: 10 CANNOT_TELL, 2 BELOW.

## Files

- results/fedsep_summary.json: the feed as served at https://indahl.ai/fedsep/live.json when this pack was built.
- results/fedsep_summary.csv: the same file flattened to one row per value, with its path.
- results/fedsep_outcomes.json and results/fedsep_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/rows.json and results/rows.csv: one row per item the desk reads (78 rows).
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served and the per-item rows, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
