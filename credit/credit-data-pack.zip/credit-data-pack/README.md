# CREDIT Data Pack

Heuremen LLC · https://indahl.ai/credit

As of 2026-11-10T18:10:06Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated complaint responses and card terms against the public record. The page states it in full at https://indahl.ai/credit.

## The ruler

Reading: above if the whole 95% interval is above the band, below if it is under the band, consistent if it lies inside, otherwise cannot tell. For 2025 the report also says “more than 99%”. Against that the 2025 interval reads consistent (shown only). A company with no complaint flagged not timely has a bootstrap interval of zero width. The Wilson interval, which does not draw months, is shown beside it and decides nothing. Under it 15 of the below readings in 2025 would read cannot tell and 3 cannot tell readings would read above. This column was added after the data. “Servicer under contract with Federal Student Aid” is the name the database gives, and every one of its rows records an untimely response. For 2025 the database shows 97.0 percent sent in 0 or 1 day, with a 95% interval of 95.5 to 98.2 percent, and the reading is cannot tell. Earlier years have no printed figure and are shown only. APRs in percent. A plan's purchase APR is the survey's median purchase APR for that plan (in the 2022 second-half file, the median APR column of the purchase section). The top 25 issuer flag is in the files from the second half of 2023. Plans with no purchase APR in the median column are counted and left out of the medians. Up to the first half of 2024 about four plans in ten carry a median, from the second half of 2024 about nineteen in twenty, so the medians do not run as one series across that change. The files write 9.99 or 9.98 in an APR cell for not applicable (999 percent). Those 159 cells are counted apart and left out.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/credit_outcomes.csv holds 339 rows: 84 BELOW, 30 CANNOT_TELL, 15 ABOVE, 1 CONSISTENT.

## Files

- results/credit_summary.json: the feed as served at https://indahl.ai/credit/live.json when this pack was built.
- results/credit_summary.csv: the same file flattened to one row per value, with its path.
- results/credit_outcomes.json and results/credit_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
