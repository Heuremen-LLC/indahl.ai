# CREDIT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 18:17 UTC and checked against the live feed at https://indahl.ai/credit/live.json.

- holds: credit_summary.csv: 3507 rows, one per value of the live feed (3507)
- holds: credit_outcomes.csv: 339 rows, the live feed holds 339 results, outcome, n, lo and hi equal on every row
- holds: credit_summary.json: byte for byte the live feed (sha256 f5da55d33a36cdb6)
- holds: page headline "99.55%": 99.55% is in the pack

TESTED 2026-11-10 18:17 UTC: 4 checks, every one holds.
