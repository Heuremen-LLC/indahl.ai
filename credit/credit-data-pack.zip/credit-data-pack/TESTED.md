# CREDIT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 13:12 UTC and checked against the live feed at https://indahl.ai/credit/live.json.

- holds: credit_summary.csv: 3796 rows, one per value of the live feed (3796)
- holds: credit_outcomes.csv: 339 rows, the live feed holds 339 results, outcome, n, lo and hi equal on every row
- holds: credit_summary.json: byte for byte the live feed (sha256 5777e0af53c4796e)
- holds: page headline "99.55%": 99.55% is in the pack

TESTED 2026-11-13 13:12 UTC: 4 checks, every one holds.
