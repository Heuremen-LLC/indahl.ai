# CREDIT Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-13T11:59:38Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| CFPB Consumer Complaint Database (company-level counts only, no complaint text or ZIP code) | https://www.consumerfinance.gov/data-research/consumer-complaints/ | CC0 as the CFPB search service states, U.S. government work | 2026-11-13T11:59:38Z |
| CFPB Consumer Response Annual Reports 2021 to 2025 | https://www.consumerfinance.gov/data-research/research-reports/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-13T11:59:38Z |
| CFPB Terms of Credit Card Plans survey | https://www.consumerfinance.gov/data-research/credit-card-data/terms-credit-card-plans-survey/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-13T11:59:38Z |
| Federal Reserve G.19 Consumer Credit, terms of credit | https://www.federalreserve.gov/releases/g19/ | Federal Reserve Board data, public | 2026-11-13T11:59:38Z |
