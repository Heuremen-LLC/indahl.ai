# AIRQ Data Pack

Heuremen LLC · https://indahl.ai/airq

As of 10 Nov 2026 02:09, the time stamped on the desk's feed when this pack was built.

## The question

Air sensors against the EPA's own targets. The page states it in full at https://indahl.ai/airq.

## The ruler

The ruler and the outcome rules are stated on the page at https://indahl.ai/airq.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/airq_outcomes.csv holds 9 rows: 6 ABOVE, 2 CANNOT_TELL, 1 BELOW.

## Files

- results/airq_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/airq_summary.csv: the same file flattened to one row per value, with its path.
- results/airq_outcomes.json and results/airq_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because PurpleAir terms allow its data and anything derived from it only for internal testing and bar passing it on.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
