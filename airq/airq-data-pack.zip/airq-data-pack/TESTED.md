# AIRQ Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 15:50 UTC and checked against the live feed at https://indahl.ai/airq/live.json.

- holds: airq_summary.csv: 122 rows, one per value of the live feed (122)
- holds: airq_outcomes.csv: 9 rows, the live feed holds 9 results, outcome, n, lo and hi equal on every row
- holds: page headline "129 and 70 of 139": 129 is in the pack
- holds: page headline "129 and 70 of 139": 70 is in the pack
- holds: page headline "129 and 70 of 139": 139 is in the pack

TESTED 2026-11-11 15:50 UTC: 5 checks, every one holds.
