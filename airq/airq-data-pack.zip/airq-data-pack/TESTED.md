# AIRQ Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 03:32 UTC and checked against the live feed at https://indahl.ai/airq/live.json.

- holds: airq_summary.csv: 122 rows, one per value of the live feed (122)
- holds: airq_outcomes.csv: 9 rows, the live feed holds 9 results, outcome, n, lo and hi equal on every row
- holds: page headline "70 to 129": 70 is in the pack
- holds: page headline "70 to 129": 129 is in the pack

TESTED 2026-11-12 03:32 UTC: 4 checks, every one holds.
