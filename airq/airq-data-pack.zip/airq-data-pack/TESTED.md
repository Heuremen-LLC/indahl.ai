# AIRQ Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 13:44 UTC and checked against the live feed at https://indahl.ai/airq/live.json.

- holds: airq_summary.csv: 100 rows, one per value of the live feed (100)
- holds: airq_outcomes.csv: 11 rows, the live feed holds 11 results, outcome, n, lo and hi equal on every row
- holds: page headline "93%": 93% is in the pack

TESTED 2026-11-10 13:44 UTC: 3 checks, every one holds.
