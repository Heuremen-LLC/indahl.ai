# AIRQ Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 10 Nov 2026 02:09, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| EPA Air Quality System (AQS) API | https://aqs.epa.gov/aqsweb/documents/data_api.html | U.S. government work, public domain (17 U.S.C. 105) | 10 Nov 2026 02:09 |
| EPA AirNow | https://www.airnow.gov/ | U.S. government work, public domain (17 U.S.C. 105), preliminary data | 10 Nov 2026 02:09 |
| PurpleAir API | https://www.purpleair.com/policies/terms-of-service | PurpleAir terms of service, no redistribution | 10 Nov 2026 02:09 |
