# HFLICENSE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 16:17 UTC and checked against the live feed at https://indahl.ai/hflicense/live.json.

- holds: hflicense_summary.csv: 55 rows, one per value of the live feed (55)
- holds: hflicense_outcomes.csv: 4 rows, the live feed holds 4 results, outcome, n, lo and hi equal on every row

TESTED 2026-11-11 16:17 UTC: 2 checks, every one holds.
