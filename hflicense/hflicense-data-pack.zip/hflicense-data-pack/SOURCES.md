# HFLICENSE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 14 Nov 2026 11:15, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Hugging Face Hub API | https://huggingface.co/docs/hub/api | Hugging Face terms of service, https://huggingface.co/terms-of-service | 14 Nov 2026 11:15 |
