# HFLICENSE Data Pack

Heuremen LLC · https://indahl.ai/hflicense

As of 12 Nov 2026 11:41, the time stamped on the desk's feed when this pack was built.

## The question

Stated licenses against license files. The page states it in full at https://indahl.ai/hflicense.

## The ruler

Agree: the stated license and the file's license fall in the same family, with Creative Commons qualifiers kept (BY, NC, SA, ND). Disagree: both are named and the families differ. Above: the lower end of the 95 percent interval of the disagreement share is above 0.10. Consistent: the upper end is below 0.05. Otherwise, and with fewer than 30 comparable repositories, cannot tell. The two mismatch groups and the share with no license file were defined after the first read and carry no outcome. Source: the Hugging Face API.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/hflicense_outcomes.csv holds 4 rows: 1 CONSISTENT, 1 CANNOT_TELL.

## Files

- results/hflicense_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/hflicense_summary.csv: the same file flattened to one row per value, with its path.
- results/hflicense_outcomes.json and results/hflicense_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because the Hugging Face API is under its terms of service and not an open licence.

## Cite

Heuremen LLC, IRIS Desk Packs, Zenodo, doi:10.5281/zenodo.24110664

https://doi.org/10.5281/zenodo.24110664

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
