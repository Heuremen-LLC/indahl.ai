# YO

Heuremen LLC. YO reads an IBM calibration record and flags stale and zero entries. The exact answer computed by code is printed beside it.

Model: https://huggingface.co/indahl/YO

```
pip install mlx-lm            # Apple silicon
python yo_audit.py record.json --model indahl/YO

pip install transformers torch  # elsewhere
python yo_audit.py record.json --fused indahl/YO
```

Every result: https://indahl.ai/iris/lab
