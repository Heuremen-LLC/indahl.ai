"""T2 (Ramsey envelope) from the clocks of the 'delay' arms; T1 from the emitters (prepared |1>, same arms, plain read).
Arms (rigetti_look_lengths.py circ(), k=0): frame +100 kHz on clocks; emitters rx(pi); clocks rx(pi/2); pulse delay d; [Y hand: rz(pi/2)]; clocks rx(pi/2); read all. d = 0..15 us.
CLOCK: H(d) = (1-2 P1X) - i (1-2 P1Y); |H|^2 debiased by the shot-noise variance, averaged over rounds; fit A^2 exp(-2d/T2).  EMITTER: P1(d) = c0 + (c1-c0) exp(-d/T1), c1 = P1 at d=0 (own), c0 from the 5 Oct idle reads."""
import json, csv, numpy as np
from collections import deque
from common import *
E_ = json.load(open(T4 + '/cepheus_edges.json'))['edges']; NB = {}
for a, b in E_: NB.setdefault(a, []).append(b); NB.setdefault(b, []).append(a)
SETS = {
 'DOSE (7 Oct, rounds r1/r2/r3, sent 03:37-04:58Z)': (['lookDose_r1full', 'lookDose_r2full', 'lookDose_r3'], 'live', 'snapshot 7 Oct ~03:36Z; data 0 to ~1.7 h AFTER it (same calibration epoch)'),
 'LEN (6-7 Oct, s03/s03b/s06/s03_day2, sent 21:39Z-00:05Z)': (['lookLengths_s03', 'lookLengths_s03b', 'lookLengths_s06', 'lookLengths_s03_day2'], 'live', 'snapshot 7 Oct ~03:36Z; data 3.5-6 h BEFORE it, after the 6 Oct 18:32Z recalibration'),
}
DEL = [0, 1.5, 3, 4.5, 6, 9, 12, 15]
# idle-read c0 from the 5 Oct drift rounds (nearest idle reads to 7 Oct)
n0 = k0 = 0
for i in range(1, 23):
    for t, a in load(f'{T4}/drift_r{i:03d}.npz').items():
        if t[0] == 'cal_shared' and t[1] == 'e': n0 += a.shape[0]; k0 = k0 + a.sum(0)
C0 = k0 / n0
def fitT2g(d, y, w):
    best = None
    for T in np.geomspace(0.3, 400, 500):
        f = np.exp(-2 * (d / T) ** 2); A2 = max((w * f * y).sum() / (w * f * f).sum(), 0); r = (w * (y - A2 * f) ** 2).sum()
        if best is None or r < best[0]: best = (r, T, A2)
    return best[1]
def fitT2(d, y, w):
    best = None
    Ts = np.geomspace(0.3, 400, 500)
    for T in Ts:
        f = np.exp(-2 * d / T); A2 = (w * f * y).sum() / (w * f * f).sum(); A2 = max(A2, 0); r = (w * (y - A2 * f) ** 2).sum()
        if best is None or r < best[0]: best = (r, T, A2)
    return best[1], best[2]
res = {}; rows = []; T1rows = []
for name, (files, snap, gap) in SETS.items():
    # gather
    arr = {}   # (d, hand) -> list of arrays
    for f in files:
        for t, a in load(f'{T4}/{f}.npz').items():
            if t[0] == 'delay': arr.setdefault((float(t[3]), t[4]), []).append(a)
    p = {k: np.array([x.mean(0) for x in v]) for k, v in arr.items()}                  # rounds x Q
    n = {k: np.array([x.shape[0] for x in v]) for k, v in arr.items()}
    nr = len(p[(0.0, 'X')])
    # emitters = columns reading ~|1> at d=0 on both hands
    em = [QS[j] for j in range(len(QS)) if p[(0.0, 'X')][:, j].mean() > .8 and p[(0.0, 'Y')][:, j].mean() > .8]
    if name.startswith('DOSE'):
        print('detected emitters', em, '; script DOSE_EM = [4,12,14,22,35,43,53,55,57,88]; q55 d=0 P1 X/Y:', p[(0.0, 'X')][:, COL[55]].mean(), p[(0.0, 'Y')][:, COL[55]].mean()); em = sorted(set(em) | {55})
    # distance to nearest emitter
    dist = {}
    for q in QS:
        seen = {q: 0}; dq = deque([q]); b = None
        while dq:
            u = dq.popleft()
            if u in em: b = seen[u]; break
            for v in NB.get(u, []):
                if v not in seen: seen[v] = seen[u] + 1; dq.append(v)
        dist[q] = b
    cl = [q for q in QS if q not in em]
    def amp2(pX, pY, nX, nY):
        u = 1 - 2 * pX; v = 1 - 2 * pY
        var = 4 * pX * (1 - pX) / nX + 4 * pY * (1 - pY) / nY
        return u * u + v * v - var, var
    def t2_for(pp, nn, B=0):
        T2 = np.zeros(len(QS)); A = np.zeros(len(QS))
        Y = np.array([np.mean([amp2(pp[(d, 'X')][r], pp[(d, 'Y')][r], nn[(d, 'X')][r], nn[(d, 'Y')][r])[0] for r in range(nr)], 0) for d in DEL])   # D x Q
        V = np.array([np.mean([4 * amp2(pp[(d, 'X')][r], pp[(d, 'Y')][r], nn[(d, 'X')][r], nn[(d, 'Y')][r])[0].clip(0) * amp2(pp[(d, 'X')][r], pp[(d, 'Y')][r], nn[(d, 'X')][r], nn[(d, 'Y')][r])[1] + 2 * amp2(pp[(d, 'X')][r], pp[(d, 'Y')][r], nn[(d, 'X')][r], nn[(d, 'Y')][r])[1] ** 2 for r in range(nr)], 0) / nr for d in DEL]) + 1e-6
        for j in range(len(QS)): T2[j], A[j] = fitT2(np.array(DEL), Y[:, j], 1 / V[:, j])
        if B == 'g': return np.array([fitT2g(np.array(DEL), Y[:, j], 1 / V[:, j]) for j in range(len(QS))]), A, Y
        return T2, A, Y
    T2h, Ah, Y = t2_for(p, n)
    T2g = t2_for(p, n, 'g')[0]
    Bn = 150; T2b = np.zeros((Bn, len(QS)))
    for b in range(Bn):
        pb = {k: rng.binomial(n[k][:, None] * np.ones((1, len(QS)), int), np.clip(v, 0, 1)) / n[k][:, None] for k, v in p.items()}
        T2b[b] = t2_for(pb, n)[0]
    lo = np.percentile(T2b, 2.5, 0); hi = np.percentile(T2b, 97.5, 0)
    P = np.array([pub(snap, q)['T2'] for q in QS]); P1 = np.array([pub(snap, q)['T1'] for q in QS])
    A0 = np.sqrt(np.clip(Ah, 0, None))
    for label, sel in (('clocks >=2 links from any emitter', [q for q in cl if dist[q] is None or dist[q] >= 2]), ('all clocks', cl)):
        idx = np.array([COL[q] for q in sel]); ok = (T2h[idx] < 399) & (T2h[idx] > .31) & (A0[idx] > .5)
        idx = idx[ok]; ratio = T2h[idx] / P[idx]; m, l, h, nn_ = boot_median(np.log(ratio))
        r = dict(snapshot=snap, gap=gap, emitters=em, rounds=nr, shots_per_delay_hand_per_qubit=int(n[(0.0, 'X')].sum()), n_qubits=int(len(idx)), excluded=[int(sel[i]) for i, o in enumerate(ok) if not o],
                 median_delivered_T2_us=float(np.median(T2h[idx])), median_published_T2_us=float(np.median(P[idx])), median_ratio=float(np.exp(m)), ratio_ci95=[float(np.exp(l)), float(np.exp(h))],
                 outcome=outcome(l, h, 0.0, np.log(1.10)), median_per_qubit_relative_halfwidth=float(np.median(((hi - lo) / 2 / T2h)[idx])),
                 qubits_ci_entirely_below_pub=int((hi[idx] < P[idx]).sum()), qubits_ci_entirely_above_pub=int((lo[idx] > P[idx]).sum()),
                 median_fitted_amplitude_A=float(np.median(A0[idx])), delivered_T2_gt_2x_published_T1_qubits=[int(QS[i]) for i in idx if T2h[i] > 2 * P1[i]],
                 delivered_ramsey_over_pub_T1_median=float(np.median(T2h[idx] / P1[idx])), sensitivity_gaussian_envelope_median_ratio=[float(np.exp(x)) for x in boot_median(np.log(T2g[idx] / P[idx]))[:3]])
        res[f'{name} | {label}'] = r; print(name, '|', label, '\n ', r)
        if label.startswith('clocks'):
            for i in idx: rows.append([name.split(' ')[0], QS[i], dist[QS[i]], round(T2h[i], 2), round(lo[i], 2), round(hi[i], 2), P[i]])
    # EMITTER T1
    c1 = np.array([np.mean([p[(0.0, h)][:, COL[q]].mean() for h in 'XY']) for q in em]); c0 = np.array([C0[COL[q]] for q in em])
    ws = np.array(DEL[1:]); GRID = np.geomspace(1, 400, 800)
    Pm = np.array([[np.mean([p[(d, h)][:, COL[q]].mean() for h in 'XY']) for q in em] for d in DEL[1:]])   # D x E
    Nn = np.array([n[(d, 'X')].sum() + n[(d, 'Y')].sum() for d in DEL[1:]])
    T1e = []; T1l = []; T1h_ = []
    def fT1(Pobs, c0_, c1_):
        out = []
        for j in range(Pobs.shape[1]):
            L = [(-(Nn[:, None] * (Pobs[:, j, None] * np.log(np.clip(c0_[j] + (c1_[j] - c0_[j]) * np.exp(-ws[:, None] / GRID[None, :]), 1e-9, 1 - 1e-9)) + (1 - Pobs[:, j, None]) * np.log(np.clip(1 - (c0_[j] + (c1_[j] - c0_[j]) * np.exp(-ws[:, None] / GRID[None, :])), 1e-9, 1))))).sum(0)]
            out.append(GRID[np.argmin(L[0])])
        return np.array(out)
    th = fT1(Pm, c0, c1); Bt = np.zeros((150, len(em)))
    for b in range(150):
        mod = c0[None, :] + (c1 - c0)[None, :] * np.exp(-ws[:, None] / th[None, :])
        Pb = rng.binomial(Nn[:, None] * np.ones((1, len(em)), int), np.clip(mod, 0, 1)) / Nn[:, None]
        Bt[b] = fT1(Pb, c0, np.clip(rng.binomial(int(n[(0.0, 'X')].sum() + n[(0.0, 'Y')].sum()), c1) / int(n[(0.0, 'X')].sum() + n[(0.0, 'Y')].sum()), 0, 1))
    Pe = np.array([pub(snap, q)['T1'] for q in em]); m, l, h, k_ = boot_median(np.log(th / Pe))
    r = dict(snapshot=snap, gap=gap, emitters=em, n_qubits=len(em), c1_median=float(np.median(c1)), c0_from_5Oct_idle=float(np.median(c0)), delivered_T1_us=[round(float(x), 1) for x in th], published_T1_us=[float(x) for x in Pe],
             per_qubit_ci95=[[round(float(a), 1), round(float(b), 1)] for a, b in zip(np.percentile(Bt, 2.5, 0), np.percentile(Bt, 97.5, 0))],
             median_ratio=float(np.exp(m)), ratio_ci95=[float(np.exp(l)), float(np.exp(h))], outcome=outcome(l, h, 0.0, np.log(1.10)), F1_readout_at_d0_median=float(np.median(c1)), note='windows only to 15 us; c0 not measured on 7 Oct')
    res[f'{name} | emitter T1'] = r; print(name, '| emitter T1\n ', r)
json.dump(res, open('04_t2_t1emit.json', 'w'), indent=1)
with open('04_t2_per_qubit.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['set', 'qubit', 'links_to_nearest_emitter', 'T2ramsey_us', 'ci_lo', 'ci_hi', 'T2_us_published']); w.writerows(rows)
