"""(contrast fixed to F0+F1-1 from the same-day cal; amplitude free version gave 19 qubits at the 400 us bound and 16 at 0.5 us: too noisy, dropped)
T2 echo: triangle C 'rest' arm (4 Oct 17:23Z, pre-recal): clocks rx(pi/2), wait L, rx(pi), wait L, rx(pi/2) [Y hand: rz(pi/2) before last], emitters at rest, L = 5/10/20 us (total 2L = 10/20/40 us), 900 shots/hand.
|H|^2 debiased, fit A^2 exp(-2 t/T2e), t = 2L, 3 points / 2 params; plug-in binomial bootstrap."""
import json, csv, numpy as np
from common import *
Z = load(T4 + '/triC.npz'); G = [0.5, 1, 2]; t = np.array([20 * g for g in G]) / 2 * 1.0   # 2L = 20 g (g=0.5 -> 10 us)
t = np.array([20 * g for g in G]) * 0.5 * 2 / 2
t = np.array([10 * g * 2 for g in G])          # 2L = 10 g * 2 -> g=.5:10, g=1:20, g=2:40 us
pX = np.array([Z[('rest', g, 'X')].mean(0) for g in G]); pY = np.array([Z[('rest', g, 'Y')].mean(0) for g in G]); n = 900
EM = [7, 22, 27, 57, 62, 72, 104]
def amp2(pX, pY):
    u = 1 - 2 * pX; v = 1 - 2 * pY; var = 4 * (pX * (1 - pX) + pY * (1 - pY)) / n; return u * u + v * v - var, var
def fit(pX, pY):
    y, var = amp2(pX, pY); w = 1 / (4 * np.clip(y, 0, None) * var + 2 * var ** 2 + 1e-6); out = np.zeros(len(QS))
    Ts = np.geomspace(0.5, 400, 400)
    for j in range(len(QS)):
        best = None
        for T in Ts:
            f = np.exp(-2 * t / T); A2 = max((w[:, j] * f * y[:, j]).sum() / (w[:, j] * f * f).sum(), 0); r = (w[:, j] * (y[:, j] - A2 * f) ** 2).sum()
            if best is None or r < best[0]: best = (r, T, A2)
        out[j] = best[1]
    return out
import json as _j
_rd = _j.load(open('02_readout.json')); import csv as _c
_rows = [r for r in _c.DictReader(open('02_readout_per_qubit.csv')) if r['group'] == 'O4_pre-recal']
CON = np.array([2 * float(r['Fa_delivered']) - 1 for r in _rows])      # contrast F0+F1-1, same-day cal (4 Oct pre-recal)
def fit(pX, pY):
    y, var = amp2(pX, pY); w = 1 / (4 * np.clip(y, 0, None) * var + 2 * var ** 2 + 1e-6); out = np.zeros(len(QS)); Ts = np.geomspace(0.5, 400, 400)
    for j in range(len(QS)):
        f = np.exp(-2 * t[:, None] / Ts[None, :]) * CON[j] ** 2
        r = (w[:, j, None] * (y[:, j, None] - f) ** 2).sum(0); out[j] = Ts[np.argmin(r)]
    return out
Th = fit(pX, pY); B = 200; Tb = np.zeros((B, len(QS)))
for b in range(B):
    Tb[b] = fit(rng.binomial(n, np.clip(pX, 0, 1)) / n, rng.binomial(n, np.clip(pY, 0, 1)) / n)
lo = np.percentile(Tb, 2.5, 0); hi = np.percentile(Tb, 97.5, 0)
P = np.array([pub('live', q)['T2'] for q in QS]); Pold = np.array([pub('old', q)['T2'] for q in QS])
cl = [q for q in QS if q not in EM]; amp0 = np.sqrt(np.clip(amp2(pX, pY)[0][0], 0, None))   # amplitude at 2L=10 us
res = {}
for label, sel in (('all 100 clocks', cl),):
    idx = np.array([COL[q] for q in sel]); ok = (np.array(sel) != 41) & (np.array(sel) != 69) & (np.array(sel) != 76); idx = idx[ok]
    for nm, PP, snap in (('live 7 Oct (nearest by file stamp, 58 h later)', P, 'live'), ('28 Sep (6 days earlier)', Pold, 'old')):
        m, l, h, k = boot_median(np.log(Th[idx] / PP[idx]))
        res[f'{label} vs {nm}'] = dict(n_qubits=int(k), median_delivered_T2echo_us=float(np.median(Th[idx])), median_published_T2_us=float(np.median(PP[idx])), median_ratio=float(np.exp(m)), ratio_ci95=[float(np.exp(l)), float(np.exp(h))],
                                      outcome=outcome(l, h, 0.0, np.log(1.10)), median_per_qubit_relative_halfwidth=float(np.median(((hi - lo) / 2 / Th)[idx])),
                                      qubits_ci_below=int((hi[idx] < PP[idx]).sum()), qubits_ci_above=int((lo[idx] > PP[idx]).sum()), amp_at_10us_median=float(np.median(amp0[idx])), n_fit_at_upper_bound_400us=int((Th[idx] > 399).sum()), n_fit_at_lower_bound=int((Th[idx] < 0.51).sum()),
                                      qubits_T2echo_gt_2x_published_T1=[int(QS[i]) for i in idx if Th[i] > 2 * pub('live', QS[i])['T1']])
        print(label, nm, res[f'{label} vs {nm}'])
json.dump(res, open('05_echo.json', 'w'), indent=1)
with open('05_echo_per_qubit.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['qubit', 'T2echo_us', 'ci_lo', 'ci_hi', 'T2_pub_live_us', 'T2_pub_old_us', 'amp_at_10us']); [w.writerow([q, round(Th[COL[q]], 2), round(lo[COL[q]], 2), round(hi[COL[q]], 2), P[COL[q]], round(Pold[COL[q]], 2), round(amp0[COL[q]], 3)]) for q in cl]
