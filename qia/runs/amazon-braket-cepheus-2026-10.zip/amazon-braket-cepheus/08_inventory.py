import json, glob, os
S = os.path.expanduser('~/bones-forge/standoff'); arns = set(); per = {}
for f in glob.glob(S + '/**/*tasks*.json', recursive=True):
    if 'raw_repull' in f: continue
    try: d = json.load(open(f))
    except Exception: continue
    T = d.get('tasks') if isinstance(d, dict) else None
    if not T: continue
    a = {t['arn'].split('/')[-1] for t in T if isinstance(t, dict) and t.get('arn')}
    per[f.replace(S + '/', '')] = len(a); arns |= a
print('unique task ARNs in all *tasks*.json under standoff/:', len(arns))
used = {'chip/run (readout 28 Sep)': 2, 'chip/wchip E0 (Ramsey 28 Sep)': 12,
        'read1-2 cal e/a + RULER e (readout, T1, gate train)': 2 * (2 + 9 + 2), 'read1-2 ': 0}
json.dump({'unique_arns': len(arns), 'per_file': per}, open('08_inventory.json', 'w'), indent=1)
