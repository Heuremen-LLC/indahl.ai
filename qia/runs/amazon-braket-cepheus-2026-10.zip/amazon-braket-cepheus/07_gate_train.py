"""GATE TRAIN (NOT RB): ten back-to-back rx(pi) (32 ns each, all 107 qubits at once) from |0> ('OFF|g0') or |1> ('ON|g0'), plain read. Excess error per gate = (P(wrong) in train - P(wrong) after zero gates)/10, using the same group's idle/pi cal reads.
Descriptive only: a gate train measures coherent + incoherent population error after 10 gates and includes T1 during ~0.3 us; it is not the Clifford-averaged fidelity Braket quotes, so NO outcome is assigned (CANNOT_TELL)."""
import json, numpy as np
from common import *
out = {}
for name, files, cal in (('O4_read1-2 (pre-recal)', ['read1', 'read2'], ['read1', 'read2']), ('O4_two (post-recal)', ['two'], ['two'])):
    off = [0, 0]; on = [0, 0]; c0 = [0, 0]; c1 = [0, 0]
    for f in files:
        for t, a in load(f'{T4}/{f}.npz').items():
            if t[0] == 'OFF|g0' and t[1] == 'e': off = [off[0] + a.shape[0], off[1] + a.sum(0)]
            if t[0] == 'ON|g0' and t[1] == 'e': on = [on[0] + a.shape[0], on[1] + a.sum(0)]
            if t[0] == 'cal' and t[1] == 'e': c0 = [c0[0] + a.shape[0], c0[1] + a.sum(0)]
            if t[0] == 'cal' and t[1] == 'a': c1 = [c1[0] + a.shape[0], c1[1] + a.sum(0)]
    p_off = off[1] / off[0]; p0 = c0[1] / c0[0]; p_on = on[1] / on[0]; p1 = c1[1] / c1[0]
    e_off = (p_off - p0) / 10; e_on = (p1 - p_on) / 10
    se_off = np.sqrt(p_off * (1 - p_off) / off[0] + p0 * (1 - p0) / c0[0]) / 10; se_on = np.sqrt(p_on * (1 - p_on) / on[0] + p1 * (1 - p1) / c1[0]) / 10
    SRBi = np.array([1 - pub('live', q)['SRB'] for q in QS]); RBi = np.array([1 - pub('live', q)['RB'] for q in QS]); good = np.array([LIVE[q][2]['RANDOMIZED_BENCHMARKING'] > .5 for q in QS])
    r = dict(shots_train_per_qubit=int(off[0]), median_excess_error_per_gate_from_0=float(np.median(e_off[good])), median_excess_error_per_gate_from_1=float(np.median(e_on[good])), median_se_from_0=float(np.median(se_off)), median_se_from_1=float(np.median(se_on)),
             median_published_isolated_RB_infidelity=float(np.median(RBi[good])), median_published_simultaneous_RB_infidelity=float(np.median(SRBi[good])),
             qubits_train_error_per_gate_gt_3x_published_simul_infidelity=int(((e_off > 3 * SRBi) & good).sum()), qubits_from0_negative_beyond_3se=int(((e_off < -3 * se_off) & good).sum()),
             outcome='CANNOT_TELL (not an RB measurement)')
    out[name] = r; print(name, r)
json.dump(out, open('07_gate_train.json', 'w'), indent=1)
