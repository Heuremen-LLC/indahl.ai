import numpy as np, json
from common import *
out = {}
def line(*a):
    s = ' '.join(str(x) for x in a); print(s); out.setdefault('log', []).append(s)
line('old snapshot (cepheus_props_20260928.json): n =', len(OLD), 'qubits; missing:', [q for q in range(108) if q not in OLD]); line('live snapshot (cepheus_props_live_20261007.json): 108 keys, q8 = [0.0, 0.0, {}] (no figures); n with figures =', len(LIVE))
for snap in ('old', 'live'):
    P = {q: pub(snap, q) for q in (OLD if snap == 'old' else LIVE)}
    qs = sorted(P)
    T1 = np.array([P[q]['T1'] for q in qs]); T2 = np.array([P[q]['T2'] for q in qs]); RO = np.array([P[q]['RO'] for q in qs]); RB = np.array([P[q]['RB'] for q in qs])
    line(f'[{snap}] medians: T1 {np.median(T1):.2f} us, T2 {np.median(T2):.2f} us, readout {np.median(RO):.4f}, RB1q {np.median(RB):.5f}')
    bad = [(q, round(P[q]['T1'], 2), round(P[q]['T2'], 2)) for q in qs if P[q]['T2'] > 2 * P[q]['T1']]
    line(f'[{snap}] T2 > 2*T1 (physically impossible): {len(bad)} qubits', bad)
    line(f'[{snap}] T2 > T1: {sum(P[q]["T2"] > P[q]["T1"] for q in qs)}; qubits with fidelity > 1: RO {int((RO>1).sum())}, RB {int((RB>1).sum())}; readout <= 0.5: {int((RO<=.5).sum())}')
    if snap == 'live':
        SR = np.array([P[q]['SRB'] for q in qs]); worse = [(q, RB[i], SR[i]) for i, q in enumerate(qs) if SR[i] > RB[i]]
        line(f'[live] simultaneous RB > isolated RB (simultaneous better than isolated): {len(worse)} qubits', [(q, round(a, 5), round(b, 5)) for q, a, b in worse])
        line(f'[live] median isolated-RB infidelity {np.median(1-RB):.5f}; simultaneous {np.median(1-SR):.5f}; ratio of medians {np.median(1-SR)/np.median(1-RB):.2f}')
        line(f'[live] SRB <= 0.5 or > 1: {[q for i,q in enumerate(qs) if SR[i]<=.5 or SR[i]>1]}; RB>=1.0 exactly: {[q for i,q in enumerate(qs) if RB[i]>=1.0]}')
    # duplicates
    for nm, arr in (('T1', T1), ('T2', T2), ('RO', RO), ('RB', RB)):
        u, c = np.unique(np.round(arr, 12), return_counts=True); d = int((c > 1).sum())
        line(f'[{snap}] {nm}: {len(u)} distinct of {len(arr)}; repeated values {d}', ('(readout is quoted to 3 decimals)' if nm == 'RO' else ''))
# cross-snapshot
com = sorted(set(OLD) & set(LIVE))
for nm in ('T1', 'T2', 'RO', 'RB'):
    a = np.array([pub('old', q)[nm] for q in com]); b = np.array([pub('live', q)[nm] for q in com])
    ident = int(np.sum(np.isclose(a, b, rtol=1e-9, atol=0))); r = b / a if nm in ('T1', 'T2') else b - a
    line(f'[old vs live, {len(com)} qubits] {nm}: identical in both snapshots {ident}; median ' + ('ratio live/old %.3f' % np.median(r) if nm in ('T1','T2') else 'diff live-old %.5f' % np.median(r)) + f'; Spearman {__import__("scipy.stats").stats.spearmanr(a,b)[0]:.3f}; 25-75%% {np.percentile(r,25):.3f}..{np.percentile(r,75):.3f}')
# is live RB identical to something else? is RB = old RB rounding?
a = np.array([pub('old', q)['RB'] for q in com]); b = np.array([pub('live', q)['RB'] for q in com])
line('[old vs live] RB: qubits where live RB is within 1e-4 of old RB:', int(np.sum(np.abs(a-b) < 1e-4)), 'of', len(com))
json.dump(out, open('01_published_checks.json', 'w'), indent=1)
o5 = [q for q in OLD if OLD[q][4] == 0.5]; l5 = [q for q in LIVE if LIVE[q][2]['RANDOMIZED_BENCHMARKING'] == 0.5]; s5 = [q for q in LIVE if LIVE[q][2]['SIMULTANEOUS_RANDOMIZED_BENCHMARKING'] == 0.5]
line('RB == exactly 0.5 (the fully-depolarised floor; a sentinel, not a measurement): old', o5, '| live isolated', l5, '| live simultaneous', s5)
line('live qubits with T2 < 1 us while T1 > 10 us:', [(q, LIVE[q][0], LIVE[q][1]) for q in LIVE if LIVE[q][1] < 1 and LIVE[q][0] > 10])
line('q37, q41, q76 RB=0.5 in BOTH snapshots (identical values across snapshots): their live readout 0.838/0.800/0.529 vs old 0.905/0.887/0.529')
json.dump(out, open('01_published_checks.json', 'w'), indent=1)
