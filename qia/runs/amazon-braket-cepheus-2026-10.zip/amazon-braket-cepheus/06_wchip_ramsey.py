"""T2 Ramsey, 28 Sep (whole chip, resonant, no detune): witness_chip.py arm E0. Clocks (106, all but q0) ry(pi/2), pulse delay w, ry(-pi/2) [Y hand: rz(-pi/2) first]; q0 at rest during the wait (flipped after). w = 0.5/1/2/3/4/6 us, 2000 shots/hand, one round.
|H|^2 debiased, fit A^2 exp(-2w/T2) (A free, 6 points). Plug-in binomial bootstrap. Matched to the 28 Sep snapshot (file stamp 22:39Z)."""
import json, csv, numpy as np
from common import *
Z = load(S + '/chip/wchip.npz'); W = [0.5, 1, 2, 3, 4, 6]; n = 2000
pX = np.array([Z[('E0', w, 'X')].mean(0) for w in W]); pY = np.array([Z[('E0', w, 'Y')].mean(0) for w in W]); W = np.array(W)
def fit(pX, pY):
    u = 1 - 2 * pX; v = 1 - 2 * pY; var = 4 * (pX * (1 - pX) + pY * (1 - pY)) / n; y = u * u + v * v - var
    wt = 1 / (4 * np.clip(y, 0, None) * var + 2 * var ** 2 + 1e-6); out = np.zeros(len(QS)); A = np.zeros(len(QS)); Ts = np.geomspace(0.5, 400, 400)
    for j in range(len(QS)):
        f = np.exp(-2 * W[:, None] / Ts[None, :]); A2 = np.clip((wt[:, j, None] * f * y[:, j, None]).sum(0) / (wt[:, j, None] * f * f).sum(0), 0, None)
        r = (wt[:, j, None] * (y[:, j, None] - A2 * f) ** 2).sum(0); k = np.argmin(r); out[j] = Ts[k]; A[j] = np.sqrt(A2[k])
    return out, A
Th, Ah = fit(pX, pY); B = 200; Tb = np.zeros((B, len(QS)))
for b in range(B): Tb[b] = fit(rng.binomial(n, np.clip(pX, 0, 1)) / n, rng.binomial(n, np.clip(pY, 0, 1)) / n)[0]
lo = np.percentile(Tb, 2.5, 0); hi = np.percentile(Tb, 97.5, 0)
P = np.array([pub('old', q)['T2'] for q in QS]); P1 = np.array([pub('old', q)['T1'] for q in QS])
cl = [q for q in QS if q != 0]; idx = np.array([COL[q] for q in cl]); good = np.array([OLD[q][4] > 0.5 for q in cl])
res = {}
for label, sel in (('106 clocks', np.ones(len(idx), bool)), ('excluding RB=0.5 qubits', good)):
    ii = idx[sel]; ok = (Th[ii] < 399) & (Th[ii] > .51); m, l, h, k = boot_median(np.log(Th[ii] / P[ii]))
    res[label] = dict(n_qubits=int(k), median_delivered_T2_us=float(np.median(Th[ii])), median_published_T2_us=float(np.median(P[ii])), median_ratio=float(np.exp(m)), ratio_ci95=[float(np.exp(l)), float(np.exp(h))],
        outcome=outcome(l, h, 0.0, np.log(1.10)), median_per_qubit_relative_halfwidth=float(np.median(((hi - lo) / 2 / Th)[ii])), qubits_ci_below=int((hi[ii] < P[ii]).sum()), qubits_ci_above=int((lo[ii] > P[ii]).sum()),
        at_bounds=int((~ok).sum()), median_A=float(np.median(Ah[ii])), windows_us=[0.5, 6], note='window reaches only 6 us ~ 0.6 of the published median T2')
    print(label, res[label])
json.dump(res, open('06_wchip_ramsey.json', 'w'), indent=1)
with open('06_wchip_ramsey_per_qubit.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['qubit', 'T2ramsey_us', 'ci_lo', 'ci_hi', 'T2_pub_28Sep_us', 'A']); [w.writerow([q, round(Th[COL[q]], 2), round(lo[COL[q]], 2), round(hi[COL[q]], 2), round(P[COL[q]], 2), round(Ah[COL[q]], 3)]) for q in cl]
