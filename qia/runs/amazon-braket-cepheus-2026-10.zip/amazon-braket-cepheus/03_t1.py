"""T1: prepare |1> (rx pi, all 107 qubits in parallel), wait w (pulse delay), plain read. Model P(read 1) = c0 + (c1-c0) exp(-w/T1); c0 = P(1|idle), c1 = P(1|rx pi, no wait) from the same group's cal reads.
MLE per qubit by grid, interval = parametric bootstrap (binomial counts at the fitted T1, and c0,c1 redrawn from their own binomial counts). Delivered vs published: log-ratio, median over qubits, bootstrap over qubits."""
import json, csv, numpy as np
from common import *
GR = {
 'O4_read1-2 (4 Oct 16:30-16:34Z, pre-recal; waits 3/10/30 us x 3 copies x 2 batches)': dict(files=['read1','read2'], pat='RULER|ON|w', calfiles=['read1','read2'], snap='live',
      gap='snapshot 7 Oct ~03:36Z; data ~59 h before, two recalibrations in between'),
 'O4_two (4 Oct 19:29Z, post-recal; waits 1/2.6/6.9/17.9/47 us x 3 copies)': dict(files=['two'], pat='RULER|ON|w', calfiles=['two'], snap='live',
      gap='snapshot 7 Oct ~03:36Z; data ~56 h before, one recalibration (6 Oct 18:32Z) in between'),
}
GRID = np.geomspace(0.5, 600, 600)
def ll(k, n, p):
    p = np.clip(p, 1e-9, 1 - 1e-9); return k * np.log(p) + (n - k) * np.log(1 - p)
def fit(ws, K, N, c0, c1):
    # ws (m,), K,N (m,Q) counts, c0,c1 (Q,) -> T1 (Q,)
    s = np.exp(-ws[:, None, None] / GRID[None, :, None])              # m,G,1
    p = c0[None, None, :] + (c1 - c0)[None, None, :] * s              # m,G,Q
    L = ll(K[:, None, :], N[:, None, :], p).sum(0)                    # G,Q
    return GRID[np.argmax(L, 0)], L
res = {}; rows = []; store = {}
for name, g in GR.items():
    cells = {}; c0n = c0k = c1n = c1k = 0
    for f in g['files']:
        Z = load(S + '/time20261004/' + f + '.npz')
        for t, arr in Z.items():
            if t[0].startswith(g['pat']) and t[1] == 'e' and not t[0].endswith('OFF'):
                w = float(t[0].split('|w')[1].split('|')[0]); cells.setdefault(w, []).append(arr)
    for f in g['calfiles']:
        Z = load(S + '/time20261004/' + f + '.npz')
        for t, arr in Z.items():
            if t[0] == 'cal' and t[1] == 'e': c0n += arr.shape[0]; c0k = c0k + arr.sum(0)
            if t[0] == 'cal' and t[1] == 'a': c1n += arr.shape[0]; c1k = c1k + arr.sum(0)
    ws = np.array(sorted(cells)); K = np.array([sum(a.sum(0) for a in cells[w]) for w in ws]); N = np.array([[sum(a.shape[0] for a in cells[w])] * len(QS) for w in ws])
    c0 = c0k / c0n; c1 = c1k / c1n
    T1h, L = fit(ws, K, N, c0, c1)
    # parametric bootstrap
    B = 300; T1b = np.zeros((B, len(QS)))
    s = np.exp(-ws[:, None] / T1h[None, :]); ph = c0[None, :] + (c1 - c0)[None, :] * s
    for b in range(B):
        c0b = rng.binomial(c0n, c0) / c0n; c1b = rng.binomial(c1n, c1) / c1n
        Kb = rng.binomial(N, np.clip(ph, 0, 1)); T1b[b], _ = fit(ws, Kb, N, c0b, c1b)
    lo = np.percentile(T1b, 2.5, 0); hi = np.percentile(T1b, 97.5, 0)
    P = np.array([pub(g['snap'], q)['T1'] for q in QS]); ratio = T1h / P
    edge = (T1h <= GRID[0] * 1.001) | (T1h >= GRID[-1] * .999)
    okq = ~edge & (c1 - c0 > 0.5)
    lr = np.log(ratio[okq]); m, lo_m, hi_m, n = boot_median(lr)
    r = dict(snapshot=g['snap'], gap=g['gap'], waits_us=ws.tolist(), shots_per_wait_per_qubit=int(N[0, 0]), n_qubits_fit=int(okq.sum()), n_excluded=[int(q) for q, o in zip(QS, okq) if not o],
             median_delivered_T1_us=float(np.median(T1h[okq])), median_published_T1_us=float(np.median(P[okq])), median_ratio=float(np.exp(m)), ratio_ci95=[float(np.exp(lo_m)), float(np.exp(hi_m))],
             outcome=outcome(lo_m, hi_m, 0.0, np.log(1.10)), margin='ratio 0.91..1.10',
             median_per_qubit_relative_halfwidth=float(np.median((hi - lo)[okq] / 2 / T1h[okq])),
             qubits_delivered_ci_entirely_below_pub=int(((hi < P) & okq).sum()), qubits_delivered_ci_entirely_above_pub=int(((lo > P) & okq).sum()),
             qubits_ratio_gt_2=[int(q) for q, r_, o in zip(QS, ratio, okq) if o and r_ > 2], qubits_ratio_lt_0p5=[int(q) for q, r_, o in zip(QS, ratio, okq) if o and r_ < .5])
    from scipy.stats import spearmanr
    r['spearman_delivered_vs_published'] = float(spearmanr(T1h[okq], P[okq])[0]); r['log_ratio_IQR_factor'] = [float(np.exp(np.percentile(lr, 25))), float(np.exp(np.percentile(lr, 75)))]
    store[name] = (T1h, okq)
    res[name] = r; print(name, '\n ', r)
    for q, t, l, h, p_, o in zip(QS, T1h, lo, hi, P, okq): rows.append([name.split(' ')[0], q, round(t, 2), round(l, 2), round(h, 2), p_, int(o)])
json.dump(res, open('03_t1.json', 'w'), indent=1)
with open('03_t1_per_qubit.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['group', 'qubit', 'T1_us_delivered', 'ci_lo', 'ci_hi', 'T1_us_published', 'used']); w.writerows(rows)

(a, oa), (b, ob) = list(store.values()); ok = oa & ob
from scipy.stats import spearmanr
cmp = dict(note='our own two T1 sets (pre- vs post-recal, ~3 h apart)', n=int(ok.sum()), spearman=float(spearmanr(a[ok], b[ok])[0]), ratio_post_over_pre_median=float(np.median(b[ok] / a[ok])), ratio_IQR=[float(np.percentile(b[ok] / a[ok], 25)), float(np.percentile(b[ok] / a[ok], 75))])
print(cmp); res['_own_set_vs_set'] = cmp
json.dump(res, open('03_t1.json', 'w'), indent=1)
