"""READOUT: delivered assignment fidelity Fa = ((1-P(1|idle)) + P(1|rx(pi)))/2 from the 'e' (idle, read) and 'a' (rx pi, read) reads of every qubit in parallel (verbatim box, 107 qubits)."""
import glob, json, csv, numpy as np
from common import *
GROUPS = {
 'S28_run (28 Sep 22:52-23:02Z, 5000 shots)': (['chip/run.npz'], 'old', 'snapshot file written ~22:39Z 28 Sep (mtime 18:39 EDT); data +13..+23 min after'),
 'O4_pre-recal (4 Oct 16:30-17:51Z; read1-3, triA-F, G)': (['time20261004/read1.npz','time20261004/read2.npz','time20261004/read3.npz','time20261004/triA.npz','time20261004/triB.npz','time20261004/triC.npz','time20261004/triD.npz','time20261004/triE.npz','time20261004/triF.npz','time20261004/triG.npz'], 'live', 'snapshot 7 Oct ~03:36Z; data 57-59 h BEFORE it, two recalibrations (4 Oct 18:02Z, 6 Oct 18:32Z) in between'),
 'O4_post-recal (4 Oct 18:40Z-19:30Z; sealB, two)': (['time20261004/sealB.npz','time20261004/two.npz'], 'live', 'snapshot 7 Oct ~03:36Z; data ~56 h BEFORE it, one recalibration (6 Oct 18:32Z) in between'),
 'O5_drift (5 Oct 10:58-13:04Z; 22 rounds)': ([f'time20261004/drift_r{i:03d}.npz' for i in range(1, 23)], 'live', 'snapshot 7 Oct ~03:36Z; data ~39-41 h BEFORE it, one recalibration (6 Oct 18:32Z) in between'),
}
def counts(files):
    n0 = k0 = n1 = k1 = 0; nrd = 0; per = []
    for f in files:
        Z = load(S + '/' + f); got = False
        a0 = a1 = None
        for t, arr in Z.items():
            if t[0] in ('cal', 'cal_shared', 'shuffle') and len(t) >= 2 and t[1] in ('e', 'a'):
                if t[1] == 'e': a0 = (arr.shape[0], arr.sum(0))
                else: a1 = (arr.shape[0], arr.sum(0))
        # take all e and a arrays in file (a file may hold several cal copies: sum them)
        for t, arr in Z.items():
            if t[0] in ('cal', 'cal_shared', 'shuffle') and len(t) >= 2 and t[1] in ('e', 'a'):
                nrd += 1
                if t[1] == 'e': n0 = n0 + arr.shape[0]; k0 = k0 + arr.sum(0)
                else: n1 = n1 + arr.shape[0]; k1 = k1 + arr.sum(0)
        if a0 and a1: per.append((f, 1 - (a0[1] / a0[0]), a1[1] / a1[0]))
    return n0, k0, n1, k1, per
res = {}; rows = []
for name, (files, snap, gap) in GROUPS.items():
    n0, k0, n1, k1, per = counts(files)
    F0 = 1 - k0 / n0; F1 = k1 / n1; Fa = (F0 + F1) / 2
    se = 0.5 * np.sqrt(F0 * (1 - F0) / n0 + F1 * (1 - F1) / n1)
    P = np.array([pub(snap, q)['RO'] for q in QS]); RBp = np.array([pub(snap, q)['RB'] for q in QS])
    d = Fa - P; z = d / se
    m, lo, hi, n = boot_median(d)
    ratio = (1 - Fa) / (1 - P); rm, rlo, rhi, _ = boot_median(ratio)
    good = RBp > 0.5; mg, lg, hg, ng = boot_median(d[good])
    r = dict(snapshot=snap, gap=gap, n_qubits=n, shots_idle_per_qubit=int(n0), shots_pi_per_qubit=int(n1), median_delivered_Fa=float(np.median(Fa)), median_published=float(np.median(P)),
             median_diff=m, ci95=[lo, hi], outcome=outcome(lo, hi, 0.0, 0.005), margin=0.005,
             infidelity_ratio_median=rm, infidelity_ratio_ci95=[rlo, rhi], median_diff_excluding_RB0p5=[mg, lg, hg, ng],
             qubits_delivered_above_pub_by_3sigma=int((z > 3).sum()), qubits_below_by_3sigma=int((z < -3).sum()),
             median_F0=float(np.median(F0)), median_F1=float(np.median(F1)), median_se=float(np.median(se)),
             pub_rounding_note='published readout quoted to 3 decimals')
    r['qubits_delivered_below_pub_by_gt_0.05'] = [int(q) for q, x in zip(QS, d) if x < -0.05]
    r['qubits_delivered_above_pub_by_gt_0.02'] = [int(q) for q, x in zip(QS, d) if x > 0.02]
    if len(per) > 3:   # round-to-round stability of the median
        md = [float(np.median(0.5 * (a + b) - P)) for _, a, b in per]; r['per_round_median_diff_min_max'] = [min(md), max(md)]
    res[name] = r
    for q, f0, f1, fa, s, p, dd in zip(QS, F0, F1, Fa, se, P, d): rows.append([name.split(' ')[0], q, round(f0, 5), round(f1, 5), round(fa, 5), round(s, 5), p, round(dd, 5)])
    print(name, '\n ', {k: (round(v, 5) if isinstance(v, float) else v) for k, v in r.items() if k not in ('gap',)})
json.dump(res, open('02_readout.json', 'w'), indent=1)
with open('02_readout_per_qubit.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['group', 'qubit', 'F0_idle', 'F1_pi', 'Fa_delivered', 'se', 'published_RO', 'diff']); w.writerows(rows)
