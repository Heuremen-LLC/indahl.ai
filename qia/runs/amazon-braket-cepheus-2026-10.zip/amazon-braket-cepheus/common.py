import json, os, numpy as np
S = os.path.expanduser('~/bones-forge/standoff'); T4 = S + '/time20261004'
OLD = {int(r[0]): r for r in json.load(open(S + '/cepheus_props_20260928.json'))}   # [q, T1_s, T2_s, readout, RB1q]
LIVE_ALL = {int(k): v for k, v in json.load(open(S + '/cepheus_props_live_20261007.json')).items()}
LIVE = {q: v for q, v in LIVE_ALL.items() if v[2]}   # q8 is [0.0, 0.0, {}] in the live file (no figures)  # q -> [T1_us, T2_us, {RB, SRB, READOUT}]
QS = sorted(OLD)                       # 107 measured columns = these qubits (q8 absent from 9/28 file and from every circuit)
COL = {q: i for i, q in enumerate(QS)}
def pub(snap, q):
    if snap == 'old': r = OLD[q]; return dict(T1=r[1]*1e6, T2=r[2]*1e6, RO=r[3], RB=r[4], SRB=None)
    r = LIVE[q]; d = r[2]; return dict(T1=r[0], T2=r[1], RO=d['READOUT'], RB=d['RANDOMIZED_BENCHMARKING'], SRB=d['SIMULTANEOUS_RANDOMIZED_BENCHMARKING'])
def load(path):
    Z = np.load(path); return {tuple(json.loads(k)): Z[k] for k in Z.files}
rng = np.random.default_rng(20261023)
def boot_median(x, B=10000, stat=np.median):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    idx = rng.integers(0, len(x), (B, len(x))); m = stat(x[idx], axis=1)
    return float(stat(x)), float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5)), len(x)
def outcome(lo, hi, null, margin):
    """ABOVE: whole 95% interval above null; BELOW: whole interval below; CONSISTENT: interval inside null+-margin; else CANNOT_TELL"""
    if lo > null: return 'ABOVE'
    if hi < null: return 'BELOW'
    if lo >= null - margin and hi <= null + margin: return 'CONSISTENT'
    return 'CANNOT_TELL'
