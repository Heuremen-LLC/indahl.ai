# QIA List Pack

Heuremen LLC. The QIA List in files you can open in a spreadsheet, a reference manager or a LaTeX project. Page: https://indahl.ai/qia/list

## Files

- `list.json`: The List as published at https://indahl.ai/qia/list, unchanged. Top-level keys are note, terms and studies.
- `list.csv`: One row per study, with every field of list.json. Codes are joined with spaces. Basis is written as CODE: text, with several entries separated by a vertical bar. The column indahl_url points to the study on the List page. 
- `KEY.csv`: The codes and what they mean, copied from https://indahl.ai/qia/key.
- `references.bib`: One BibTeX entry for each study on the List. These are other people's papers. Each entry carries the title and link as listed, the arXiv number or DOI when the link holds one, and a note that points to the List. No authors or years are given because the List does not carry them.
- `references.ris`: The same entries in RIS format.
- `CITE_THE_LIST.bib`: One BibTeX entry for the QIA List itself.
- `CITATION.cff`: Citation file for the List.
- `TESTED.md`: What was tested before release and what was not.
- `verify.py`: Checks that the files agree with each other. Run python3 verify.py in this folder.
- `LICENSE.txt`: Terms for this data.
- `START_HERE.html`: This page.

The version column holds free text as the List records it, for example "published version" or "as read 2026-11-01". It is not only an arXiv version number.

Some studies have codes and no basis text. In this data 61 studies have codes and an empty basis. The List records no basis text for those rows.

A few links that list.json gives as http are written as https in the other files, because their host serves https.

17 rows have no indexed date in the source, so that cell is blank.

In list.csv, codes are separated by spaces and the reasons in the basis column are separated by " | ". A few reasons contain that sequence themselves, so read list.json when you need each reason exactly. A title that starts with a minus sign can be read as a formula by a spreadsheet, so import list.csv as text.

## Codes

The codes are explained in KEY.csv and at the key page: https://indahl.ai/qia/key

## Import

- Zotero: choose File, then Import, and select references.bib or references.ris.
- BibTeX or LaTeX: copy references.bib next to your document and cite an entry with its key, for example `\cite{qia-arxiv-2509.20558}`. To cite the List itself use CITE_THE_LIST.bib. Titles are UTF-8 and some hold Greek, Cyrillic or math characters, so use biber with LuaLaTeX or XeLaTeX, or a recent LaTeX with UTF-8 input.
- Spreadsheet: open list.csv. It is UTF-8 with a header row. In Excel use Data, then From Text/CSV, and pick UTF-8.

## Terms

Free to download and cite with attribution. All rights reserved. Text and data mining and use as AI training data are not permitted: https://indahl.ai/terms#ai-training Reference HLC-87D6B26B.

Each listed study keeps its own terms. Names appear as published. To have a name or a study removed: https://indahl.ai/contact

## Compile

references.bib is written for biblatex with biber and LuaLaTeX or XeLaTeX. 165 titles hold characters outside ASCII, such as Cyrillic, Greek, subscripts and dashes, so classic bibtex with pdflatex will stop on them. A minimal example:

```
\documentclass{article}
\usepackage[backend=biber]{biblatex}
\addbibresource{references.bib}
\begin{document}
Text \cite{qia-arxiv-2509.20558}.
\printbibliography
\end{document}
```

Run `lualatex main`, then `biber main`, then `lualatex main` twice more. Replace lualatex with xelatex if you prefer.

## Check

Run `python3 verify.py` in this folder. It compares the row counts of list.json, list.csv, references.bib and references.ris, checks the BibTeX braces and keys, and checks that every link starts with https://

## More

The site: https://indahl.ai

Code: https://github.com/Heuremen-LLC/indahl.ai

Built 2026-11-12.
