# AILUMINATE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 11 Nov 2026 22:37, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| MLCommons AILuminate results | https://mlcommons.org/ailuminate/ | MLCommons terms of use, https://mlcommons.org/policies/ | 11 Nov 2026 22:37 |
