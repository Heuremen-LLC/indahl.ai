# AILUMINATE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 05:38 UTC and checked against the live feed at https://indahl.ai/ailuminate/live.json.

- holds: ailuminate_summary.csv: 64 rows, one per value of the live feed (64)
- holds: ailuminate_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: page headline "4 to 100": 4 is a source value this pack leaves out, and it is in the live feed
- holds: page headline "4 to 100": 100 is a source value this pack leaves out, and it is in the live feed

TESTED 2026-11-13 05:38 UTC: 4 checks, every one holds.
