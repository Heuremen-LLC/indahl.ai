# WATER Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-14 11:36, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Reclamation 24-Month Study | https://data.usbr.gov/rise/api/catalog-record/6331 | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-14 11:36 |
| Reclamation HDB | https://www.usbr.gov/pn-bin/hdb/hdb.pl | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-14 11:36 |
| USGS water data | https://waterdata.usgs.gov/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-14 11:36 |
| California CDEC (live panel only) | https://cdec.water.ca.gov/ | California DWR public data | 2026-11-14 11:36 |
