# WATER Data Pack

Heuremen LLC · https://indahl.ai/water

As of 2026-11-13 18:05, the time stamped on the desk's feed when this pack was built.

## The question

Reservoir forecasts against measured levels. The page states it in full at https://indahl.ai/water.

## The ruler

Inside means the measured end-of-month elevation lies between the Probable Minimum and Probable Maximum projections issued in the same month. Above and below mean outside that range. Each interval is a 95% Wilson interval counted on water years, because months in one water year share weather. It treats water years as independent, and at leads past about six months neighbouring water years are correlated. Band outcome: above if the lower bound is over 80 percent, below if the upper bound is under 80 percent, consistent if the interval lies inside 70 to 90 percent, otherwise cannot tell with the reason STRADDLES_EDGE, and cannot tell with the reason TOO_WIDE_TO_RESOLVE with fewer than 10 water years. Edges are closed. No size that matters is named for these cells, so the check for an interval that holds both zero and a size that matters is not applied. Most Probable outcome: the same rule around 50 percent, with 40 to 60 percent for consistent. With about 20 water years in a cell no interval is narrow enough to read consistent, so a cell reads a miss or cannot tell. Error is the measured elevation minus the Most Probable projection, in feet. Data: Reclamation RISE and HDB, Reclamation Lower Colorado daily report, USGS Water Services and California CDEC, all read without a key.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/water_outcomes.csv holds 495 rows: 268 CANNOT_TELL, 196 BELOW, 17 ABOVE, 14 CONSISTENT.

## Files

- results/water_summary.json: the feed as served at https://indahl.ai/water/live.json when this pack was built.
- results/water_summary.csv: the same file flattened to one row per value, with its path.
- results/water_outcomes.json and results/water_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/rows.json and results/rows.csv: one row per item the desk reads (15222 rows).
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served and the per-item rows, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, ATLAS Data Pack, Zenodo, doi:10.5281/zenodo.23874305

https://doi.org/10.5281/zenodo.23874305

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
