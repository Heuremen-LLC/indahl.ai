# TORNADO Data Pack

Heuremen LLC · https://indahl.ai/tornado

As of 2026-11-14T06:19:23Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated tornado chances and warning goals against the tornadoes that came. The page states it in full at https://indahl.ai/tornado.

## The ruler

Reading: above if the whole 95% interval is above the band, below if the whole interval is under it, consistent if it lies inside the band, otherwise cannot tell. A band is closed at its lower edge and open at its upper edge. Cannot tell carries one reason. STRADDLES_EDGE means the interval overlaps an edge of the band. TOO_WIDE_TO_RESOLVE means the band has fewer than 30 days with points in it. NO_INTERVAL_FORMABLE means it has none. No size that matters is named for the bands, so the both-alternatives test is not applied. The column against the contour value reads the observed share against the value drawn, which has no tolerance, so it reads above, below or cannot tell and never consistent. A point-day is one grid point on one outlook day. The preliminary reports read for this page carry no rating, so the hatched area cannot be read for this year until the database is out. Beside these readings: 0 NOTHING_RETURNED. CANNOT_TELL 23 of 63 (23 STRADDLES_EDGE). Each goal is a one-sided threshold, so a reading is above, below or cannot tell and never consistent. For detection and lead time, above means the whole interval is at or above the goal, which meets it, and below means the whole interval is under the goal, which misses it. For false alarms, below means the whole interval is at or under 71 percent, which meets the goal, and above means the whole interval is over it, which misses it. Otherwise cannot tell, with the reason STRADDLES_EDGE. No size that matters is named for the goals, so the both-alternatives test is not applied. The first row pools the closed fiscal years. Every warning and every tornado in the files is used, in any state or territory, with no match by forecast office. Fiscal years from FY2026 on use the preliminary reports for 2026 and are labelled preliminary. A preliminary report is one point at one time, so it counts as a tornado of one minute.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/tornado_outcomes.csv holds 154 rows: 64 CANNOT_TELL, 38 BELOW, 15 ABOVE, 12 CONSISTENT.

## Files

- results/tornado_summary.json: the feed as served at https://indahl.ai/tornado/live.json when this pack was built.
- results/tornado_summary.csv: the same file flattened to one row per value, with its path.
- results/tornado_outcomes.json and results/tornado_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
