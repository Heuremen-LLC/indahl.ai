# TORNADO Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-11T21:57:58Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| NOAA SPC Day 1 Convective Outlooks (Iowa Environmental Mesonet archive) | https://mesonet.agron.iastate.edu/request/gis/outlooks.phtml | U.S. government work, public domain (17 U.S.C. 105), IEM materials are in the public domain | 2026-11-11T21:57:58Z |
| SPC tornado database and preliminary storm reports | https://www.spc.noaa.gov/wcm/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-11T21:57:58Z |
| NWS storm-based tornado warnings (Iowa Environmental Mesonet archive) | https://mesonet.agron.iastate.edu/vtec/ | U.S. government work, public domain (17 U.S.C. 105), IEM materials are in the public domain | 2026-11-11T21:57:58Z |
| US Census cartographic boundary files | https://www.census.gov/geographies/mapping-files/time-series/geo/cartographic-boundary.html | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-11T21:57:58Z |
