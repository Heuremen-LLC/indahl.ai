# TORNADO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 22:42 UTC and checked against the live feed at https://indahl.ai/tornado/live.json.

- holds: tornado_summary.csv: 1689 rows, one per value of the live feed (1689)
- holds: tornado_outcomes.csv: 154 rows, the live feed holds 154 results, outcome, n, lo and hi equal on every row
- holds: tornado_summary.json: byte for byte the live feed (sha256 e91285b5c52fa2bf)
- holds: page headline "17.6%": 17.6% is in the pack

TESTED 2026-11-11 22:42 UTC: 4 checks, every one holds.
