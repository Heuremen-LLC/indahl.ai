# TORNADO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 16:15 UTC and checked against the live feed at https://indahl.ai/tornado/live.json.

- holds: tornado_summary.csv: 1646 rows, one per value of the live feed (1646)
- holds: tornado_outcomes.csv: 151 rows, the live feed holds 151 results, outcome, n, lo and hi equal on every row
- holds: tornado_summary.json: byte for byte the live feed (sha256 e364bbf5d3c1a324)
- holds: page headline "17.6%": 17.6% is in the pack

TESTED 2026-11-10 16:15 UTC: 4 checks, every one holds.
