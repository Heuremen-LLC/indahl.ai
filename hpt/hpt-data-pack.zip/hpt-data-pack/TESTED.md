# HPT Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 13:36 UTC and checked against the live feed at https://indahl.ai/hpt/live.json.

- holds: hpt_summary.csv: 112 rows, one per value of the live feed (112)
- holds: hpt_outcomes.csv: 3 rows, the live feed holds 3 results, outcome, n, lo and hi equal on every row
- holds: hpt_summary.json: byte for byte the live feed (sha256 6608dc006ccd67be)
- holds: page headline "12 of 506": 12 is in the pack
- holds: page headline "12 of 506": 506 is in the pack
- holds: rows.csv: 1921 rows, the live feed counts 1921
- holds: rows.csv: s1 counts {'NOT_COMPARABLE': 941, 'DISAGREE': 462, 'AGREE': 518} equal the live feed

TESTED 2026-11-10 13:36 UTC: 7 checks, every one holds.
