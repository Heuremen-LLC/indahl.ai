# WEIGHTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-14 03:58 UTC and checked against the live feed at https://indahl.ai/weights/live.json.

- holds: weights_summary.csv: 761 rows, one per value of the live feed (761)
- holds: weights_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: page headline "18 of 1,040": 18 is in the pack
- holds: page headline "18 of 1,040": 1,040 is in the pack

TESTED 2026-11-14 03:58 UTC: 4 checks, every one holds.
