# STACK Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 13 Nov 2026 21:43, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| The live feeds of the other desks | https://indahl.ai/stack | Heuremen LLC | 13 Nov 2026 21:43 |
