# STACK Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 12 Nov 2026 18:49, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| The live feeds of the other desks | https://indahl.ai/stack | Heuremen LLC | 12 Nov 2026 18:49 |
