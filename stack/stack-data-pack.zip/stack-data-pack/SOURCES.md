# STACK Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 14 Nov 2026 02:08, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| The live feeds of the other desks | https://indahl.ai/stack | Heuremen LLC | 14 Nov 2026 02:08 |
