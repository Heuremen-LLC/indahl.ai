# STACK Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-14 12:47 UTC and checked against the live feed at https://indahl.ai/stack/live.json.

- holds: stack_summary.csv: 688 rows, one per value of the live feed (688)
- holds: stack_outcomes.csv: 54 rows, the live feed holds 54 results, outcome, n, lo and hi equal on every row
- holds: stack_summary.json: byte for byte the live feed (sha256 94601970d49c0c1b)

TESTED 2026-11-14 12:47 UTC: 3 checks, every one holds.
