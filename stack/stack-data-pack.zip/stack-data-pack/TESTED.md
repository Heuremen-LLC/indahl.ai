# STACK Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 19:50 UTC and checked against the live feed at https://indahl.ai/stack/live.json.

- holds: stack_summary.csv: 530 rows, one per value of the live feed (530)
- holds: stack_outcomes.csv: 54 rows, the live feed holds 54 results, outcome, n, lo and hi equal on every row
- holds: stack_summary.json: byte for byte the live feed (sha256 f078002f264aa568)

TESTED 2026-11-11 19:50 UTC: 3 checks, every one holds.
