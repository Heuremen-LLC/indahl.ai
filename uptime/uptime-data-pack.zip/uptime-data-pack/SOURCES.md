# UPTIME Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 13 Nov 2026 23:10, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Vendor status pages (Statuspage JSON) | https://indahl.ai/uptime | each vendor keeps its rights | 13 Nov 2026 23:10 |
| HTTPS probes from our seats | https://indahl.ai/uptime | our own measurements | 13 Nov 2026 23:10 |
