# UPTIME Data Pack

Heuremen LLC · https://indahl.ai/uptime

As of 13 Nov 2026 18:17, the time stamped on the desk's feed when this pack was built.

## The question

Vendor status pages against independent probes. The page states it in full at https://indahl.ai/uptime.

## The ruler

Each vendor is read as the share of rounds in which the page and both seats agree, with a 95% interval, against one threshold set by the floor. Above: the whole interval is above the threshold. Below: the whole interval is below it and there are at least two separate episodes, so the service was less reachable than its page stated. Cannot tell, with its reason beside it: too wide to resolve when there are fewer than 300 rounds or fewer than two episodes, straddles edge when the interval overlaps the threshold, no interval formable when there is no round. One endpoint is not a whole service, and a disagreement is between the page and that endpoint on those seats in that round. Incidents a vendor records are its own. No ranking.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/uptime_outcomes.csv holds 20 rows: 20 CANNOT_TELL.

## Files

- results/uptime_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/uptime_summary.csv: the same file flattened to one row per value, with its path.
- results/uptime_outcomes.json and results/uptime_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because the vendor status pages state no reuse terms.

## Cite

Heuremen LLC, ATLAS Data Pack, Zenodo, doi:10.5281/zenodo.23874305

https://doi.org/10.5281/zenodo.23874305

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
