# UPTIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 00:25 UTC and checked against the live feed at https://indahl.ai/uptime/live.json.

- holds: uptime_summary.csv: 185 rows, one per value of the live feed (185)
- holds: uptime_outcomes.csv: 20 rows, the live feed holds 20 results, outcome, n, lo and hi equal on every row

TESTED 2026-11-12 00:25 UTC: 2 checks, every one holds.
