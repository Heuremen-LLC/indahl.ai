# CONE Data Pack

Heuremen LLC · https://indahl.ai/cone

As of 2026-11-11T23:02:40Z, the time stamped on the desk's feed when this pack was built.

## The question

The hurricane forecast cone against where storms went. The page states it in full at https://indahl.ai/cone.

## The ruler

A forecast is scored when it carries all seven lead times and the storm was still a tropical or subtropical cyclone in the best track at every six-hour point from 12 to 120 hours. The cone is built from NHC's circles at 12, 24, 36, 48, 72, 96 and 120 hours with that season's sizes, joined the way NHC describes, starting from the forecast's first position. Inside the whole way means every six-hour best-track point from 12 to 120 hours lies in it. Timing is not checked, as NHC's wording is about the path. Nothing returned counts forecasts whose storm track ended or stopped being tropical within five days. Those are never folded into either side. Forecasts shorter than five days are left out: Atlantic 2,236, East Pacific 2,171. The cone here leaves out the 60 h circle, as NHC's graphic page does (NHC's cone page lists it). Starting the cone at the 12 h circle instead of the first position lowers the share by 1.6 points in the Atlantic and 2.8 in the East Pacific , in the referee's recount after the data, which decides nothing. The upper end of the Atlantic interval is 0.4 points above the lower end of NHC's range. Forecasts of one storm share most of their track, so they are not independent. Each interval is a storm-level block bootstrap: storms are drawn again with replacement, all of a drawn storm's forecasts come with it, 2,000 times. Reading: consistent if the whole interval lies inside 60 to 70 percent, above if it lies above 70, below if it lies below 60, otherwise cannot tell. Inside means the best-track position at the verifying time lies within that season's circle radius of the forecast position, by great-circle distance. NHC states two-thirds. Reading two-thirds as 61.7 to 71.7 percent is our reading. Positions are compared at the tenth of a degree NHC prints, with no tolerance added. The interval is the same storm-level bootstrap. Atlantic 2026: no forecast had a full track yet, so the whole path cannot be read. East Pacific 2026: 103 of 182 forecasts with a full track stayed inside for the whole path (56.6 percent), which reads cannot tell. These seasons use the operational best track NHC keeps during the season, and they enter the cells above when the post-season best track is posted.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/cone_outcomes.csv holds 272 rows: 222 CONSISTENT, 50 CANNOT_TELL.

## Files

- results/cone_summary.json: the feed as served at https://indahl.ai/cone/live.json when this pack was built.
- results/cone_summary.csv: the same file flattened to one row per value, with its path.
- results/cone_outcomes.json and results/cone_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, ATLAS Desk Packs, Zenodo, doi:10.5281/zenodo.24118626

https://doi.org/10.5281/zenodo.24118626

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
