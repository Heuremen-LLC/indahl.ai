# CONE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-11T16:29:29Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| NOAA NHC ATCF a-decks (official forecasts) and b-decks | https://ftp.nhc.noaa.gov/atcf/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-11T16:29:29Z |
| NOAA NHC HURDAT2 best track | https://www.nhc.noaa.gov/data/hurdat/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-11T16:29:29Z |
| NOAA NHC cone definition and verification tables | https://www.nhc.noaa.gov/aboutcone.shtml | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-11T16:29:29Z |
| Internet Archive Wayback Machine copies of the NHC cone page | https://web.archive.org/ | Internet Archive terms of use, https://archive.org/about/terms.php | 2026-11-11T16:29:29Z |
