# CONE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 19:08 UTC and checked against the live feed at https://indahl.ai/cone/live.json.

- holds: cone_summary.csv: 4633 rows, one per value of the live feed (4633)
- holds: cone_outcomes.csv: 272 rows, the live feed holds 272 results, outcome, n, lo and hi equal on every row
- holds: cone_summary.json: byte for byte the live feed (sha256 9945ca2cd3668811)
- holds: page headline "697 of 1,315": 697 is in the pack
- holds: page headline "697 of 1,315": 1,315 is in the pack

TESTED 2026-11-13 19:08 UTC: 5 checks, every one holds.
