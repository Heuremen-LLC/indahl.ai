# CONE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 13:59 UTC and checked against the live feed at https://indahl.ai/cone/live.json.

- holds: cone_summary.csv: 4217 rows, one per value of the live feed (4217)
- holds: cone_outcomes.csv: 272 rows, the live feed holds 272 results, outcome, n, lo and hi equal on every row
- holds: cone_summary.json: byte for byte the live feed (sha256 b6b8f83212ba5145)
- holds: page headline "697 of 1,315": 697 is in the pack
- holds: page headline "697 of 1,315": 1,315 is in the pack

TESTED 2026-11-11 13:59 UTC: 5 checks, every one holds.
