# WIKI Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-14 05:29 UTC and checked against the live feed at https://indahl.ai/wiki/live.json.

- holds: wiki_summary.csv: 8656 rows, one per value of the live feed (8656)
- holds: wiki_outcomes.csv: 379 rows, the live feed holds 379 results, outcome, n, lo and hi equal on every row
- holds: wiki_summary.json: byte for byte the live feed (sha256 fc888f766632e48d)

TESTED 2026-11-14 05:29 UTC: 3 checks, every one holds.
