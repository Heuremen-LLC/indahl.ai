# WIKI Data Pack

Heuremen LLC · https://indahl.ai/wiki

As of 2026-11-10 05:04 UTC, the time stamped on the desk's feed when this pack was built.

## The question

Cited figures against their source. The page states it in full at https://indahl.ai/wiki.

## The ruler

Each share has two 95% intervals. Wilson treats every figure as independent. Countries resamples whole countries (2,000 draws), since the figures for one country come from one source series and are not independent of each other. The bins use neither interval. The row for all figures mixes sources with different depths of history: the World Bank archive reaches back to 1989, the UIS data API to September 2024. Defined after the data: 5,069 of its 5,093 figures that match no release read are UIS figures. Defined after the data: 12 GDP figures for Bolivia, 1960 to 1971, sit on the 1 percent line (each gap is -1.0000 percent). Their outcome turns on the ninth digit: 10 cannot tell, 2 below. Gap is the figure as cited minus the source's current figure, as a percentage of the current figure. The source's figure for a past year changes when the source revises it. A row names the newest release we read that carried the cited value. For a whole-percent unemployment figure, that release is one of many that carried the same value to the nearest point. Set aside before scoring and counted: more than one point in time 36, no point in time 4, deprecated rank 1. Statements come from the live Wikidata API. Two statements with the same country, year and value count once. Before the real figures, planted figures ran through the same rules and read as the plan requires (passed). Our pull of the 29 World Bank releases a first scout read on 9 November equals the scout's files value for value (passed). Ten figures drawn with seed 11 across all six figures were opened in the live Wikidata entity record and in the source's own record for the release their bin names: 10 of 10 agree on value, year, rank, reference, current value and bin. A first run of that check read the Wikidata Query Service instead and drew from all figures at once, and the plan notes the change. Reading: above means the stated band lies wholly above every delivered month, below means wholly below, consistent means every delivered month lies inside the stated band, and cannot tell means they overlap. The reading on the mean, a second ruler fixed before the data, places the 12-month mean against the band. The last column, for homepage rates, is descriptive and has no outcome. The two view figures name Wikipedia, so only the Wikipedia definitions decide their outcome (defined after the data). Views come from the Analytics API page view counts, edits from its edit counts divided by the minutes in each month, articles and files from each wiki's site statistics. Registered editors without bots, all pages, monthly means over each window. The public MediaWiki history dumps list a global user id (event_user_central_id), which would allow one count per person. We have not read them. Monthly values are in the data feed . Every family and window is within the bound. For Wikipedia the stated EU devices are 20% to 23% of global unique devices. Global unique devices: Analytics API, unique devices per project family, all sites, monthly, averaged over each window.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/wiki_outcomes.csv holds 379 rows: 134 BELOW, 109 CONSISTENT, 101 ABOVE, 27 CANNOT_TELL.

## Files

- results/wiki_summary.json: the feed as served at https://indahl.ai/wiki/live.json when this pack was built.
- results/wiki_summary.csv: the same file flattened to one row per value, with its path.
- results/wiki_outcomes.json and results/wiki_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt. Values whose source is UNESCO UIS or a Wikimedia Foundation page are shared under CC BY-SA 4.0, as those sources require.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
