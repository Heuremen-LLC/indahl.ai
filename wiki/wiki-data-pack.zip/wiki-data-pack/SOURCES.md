# WIKI Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-10 05:04 UTC, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Wikidata | https://www.wikidata.org/ | CC0 1.0 | 2026-11-10 05:04 UTC |
| Wikimedia Analytics API | https://wikimedia.org/api/rest_v1/ | CC0 1.0 | 2026-11-10 05:04 UTC |
| World Bank World Development Indicators | https://databank.worldbank.org/source/world-development-indicators | CC BY 4.0 | 2026-11-10 05:04 UTC |
| UNESCO Institute for Statistics | https://databrowser.uis.unesco.org/ | CC BY-SA 4.0 | 2026-11-10 05:04 UTC |
| Wikimedia Foundation pages and reports | https://wikimediafoundation.org/ | CC BY-SA 4.0 | 2026-11-10 05:04 UTC |
