# TRIALS Data Pack

Heuremen LLC · https://indahl.ai/trials

As of 2026-11-13 08:38 UTC, the time stamped on the desk's feed when this pack was built.

## The question

Results due against results posted, and stopped trials. The page states it in full at https://indahl.ai/trials.

## The ruler

The share of records with no results on the record is read against a band of 0 to 10 percent, open at 10, and 25 percent is the size that matters. Above: the whole 95 percent interval lies at or above 10 percent. Consistent: the interval sits inside the band and does not reach both 0 and 25 percent. Cannot tell: neither, and the Outcome cell gives the reason, TOO_WIDE_TO_RESOLVE when the interval reaches both 0 and 25 percent, STRADDLES_EDGE when it overlaps 10 percent, NO_INTERVAL_FORMABLE when no record is scored. The earlier rule left a range between 10 and 25 percent where a resolved share read cannot tell. The rule in the plan addendum dated 12 November 2026, committed before any reading under it, closes that range, and the headline share now reads above. The intervals treat records as independent although sponsors and programs cluster, so they are narrower than the records justify. Records and sponsor names are as the registry gives them. The count of failed reads and the share of cannot tell by reason sit beside the headline.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/trials_outcomes.csv holds 179 rows: 97 CANNOT_TELL, 41 CONSISTENT, 40 ABOVE.

## Files

- results/trials_summary.json: the feed as served at https://indahl.ai/trials/live.json when this pack was built.
- results/trials_summary.csv: the same file flattened to one row per value, with its path.
- results/trials_outcomes.json and results/trials_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
