# TRIALS Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-12 03:08 UTC, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| ClinicalTrials.gov API v2 | https://clinicaltrials.gov/data-api/api | U.S. National Library of Medicine, public data, cite ClinicalTrials.gov | 2026-11-12 03:08 UTC |
