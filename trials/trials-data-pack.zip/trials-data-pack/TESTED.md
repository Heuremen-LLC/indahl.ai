# TRIALS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 12:54 UTC and checked against the live feed at https://indahl.ai/trials/live.json.

- holds: trials_summary.csv: 1563 rows, one per value of the live feed (1563)
- holds: trials_outcomes.csv: 179 rows, the live feed holds 179 results, outcome, n, lo and hi equal on every row
- holds: trials_summary.json: byte for byte the live feed (sha256 41b5f468a034f21e)
- holds: page headline "21.5%": 21.5% is in the pack

TESTED 2026-11-12 12:54 UTC: 4 checks, every one holds.
