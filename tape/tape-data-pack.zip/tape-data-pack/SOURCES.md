# TAPE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 11 Nov 2026 18:28, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Our own hash chain of pages and feeds | https://indahl.ai/tape | Heuremen LLC | 11 Nov 2026 18:28 |
| drand randomness beacon | https://drand.love/ | public beacon | 11 Nov 2026 18:28 |
