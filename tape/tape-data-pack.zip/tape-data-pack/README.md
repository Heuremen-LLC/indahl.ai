# TAPE Data Pack

Heuremen LLC · https://indahl.ai/tape

As of 11 Nov 2026 20:03, the time stamped on the desk's feed when this pack was built.

## The question

Every page and live feed, hashed and chained, with a beacon. The page states it in full at https://indahl.ai/tape.

## The ruler

A hash proves that a page or feed existed in exactly this form at that time. It does not prove the content is true. The plan, the chain, every leaf behind every line and the verifier are public in the repository , and the verifier needs only Python. Run python3 tape_verify.py in that folder to check the whole chain. Each release of the site is also stamped on its own, with Internet Archive copies of what changed: STAMPS . Want your own receipt? VAULT hashes a file in your browser and adds the hash to this tape. The file never leaves your computer.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/tape_outcomes.csv holds 0 rows, each with an interval and no outcome word.

## Files

- results/tape_summary.json: the feed as served at https://indahl.ai/tape/live.json when this pack was built.
- results/tape_summary.csv: the same file flattened to one row per value, with its path.
- results/tape_outcomes.json and results/tape_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
