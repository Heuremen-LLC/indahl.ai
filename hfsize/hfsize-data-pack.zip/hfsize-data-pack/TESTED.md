# HFSIZE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 16:04 UTC and checked against the live feed at https://indahl.ai/hfsize/live.json.

- holds: hfsize_summary.csv: 71 rows, one per value of the live feed (71)
- holds: hfsize_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "12 of 135": 12 is in the pack
- holds: page headline "12 of 135": 135 is in the pack

TESTED 2026-11-12 16:04 UTC: 4 checks, every one holds.
