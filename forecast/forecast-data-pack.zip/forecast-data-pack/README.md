# FORECAST Data Pack

Heuremen LLC · https://indahl.ai/forecast

As of 14 Nov 2026 02:41, the time stamped on the desk's feed when this pack was built.

## The question

Stated chance against what happened. The page states it in full at https://indahl.ai/forecast.

## The ruler

Above: it happened more often than stated. Below: less often. Cannot tell: the interval holds the stated chance (STRADDLES_EDGE), or the cell has under 30 periods (TOO_WIDE_TO_RESOLVE). The plan named no tolerance, so no cell reads consistent (plan addendum of 12 November 2026, Standards 2.0). Hourly reports can miss a short shower, so the observed frequency is a floor, and the chance floor is printed with each table. Periods from one storm are not independent. No ranking.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/forecast_outcomes.csv holds 37 rows: 21 CANNOT_TELL, 15 ABOVE.

## Files

- results/forecast_summary.json: the feed as served at https://indahl.ai/forecast/live.json when this pack was built.
- results/forecast_summary.csv: the same file flattened to one row per value, with its path.
- results/forecast_outcomes.json and results/forecast_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
