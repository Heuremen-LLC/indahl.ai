# FORECAST Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 18:45 UTC and checked against the live feed at https://indahl.ai/forecast/live.json.

- holds: forecast_summary.csv: 313 rows, one per value of the live feed (313)
- holds: forecast_outcomes.csv: 36 rows, the live feed holds 36 results, outcome, n, lo and hi equal on every row
- holds: forecast_summary.json: byte for byte the live feed (sha256 0563d8c81d294404)

TESTED 2026-11-11 18:45 UTC: 3 checks, every one holds.
