# FORECAST Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 01:19 UTC and checked against the live feed at https://indahl.ai/forecast/live.json.

- holds: forecast_summary.csv: 313 rows, one per value of the live feed (313)
- holds: forecast_outcomes.csv: 36 rows, the live feed holds 36 results, outcome, n, lo and hi equal on every row
- holds: forecast_summary.json: byte for byte the live feed (sha256 1219d90c404953b1)

TESTED 2026-11-12 01:19 UTC: 3 checks, every one holds.
