# CADA Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 22:42 UTC and checked against the live feed at https://indahl.ai/cada/live.json.

- holds: cada_summary.csv: 231 rows, one per value of the live feed (231)
- holds: cada_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: cada_summary.json: byte for byte the live feed (sha256 9b0af9328edb02d9)

TESTED 2026-11-11 22:42 UTC: 3 checks, every one holds.
