# CADA Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 12 Nov 2026 16:58, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Phishing.Database active domains | https://github.com/mitchellkrogza/Phishing.Database | MIT | 12 Nov 2026 16:58 |
| CERT Polska warning list | https://cert.pl/en/warning-list/ | CERT Polska terms | 12 Nov 2026 16:58 |
| Answers of public DNS resolvers | https://indahl.ai/cada | our own measurements | 12 Nov 2026 16:58 |
