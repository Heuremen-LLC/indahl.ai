# CADA Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 11 Nov 2026 21:25, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Phishing.Database active domains | https://github.com/mitchellkrogza/Phishing.Database | MIT | 11 Nov 2026 21:25 |
| CERT Polska warning list | https://cert.pl/en/warning-list/ | CERT Polska terms | 11 Nov 2026 21:25 |
| Answers of public DNS resolvers | https://indahl.ai/cada | our own measurements | 11 Nov 2026 21:25 |
