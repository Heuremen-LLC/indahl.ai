# CADA Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 14 Nov 2026 03:42, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Phishing.Database active domains | https://github.com/mitchellkrogza/Phishing.Database | MIT | 14 Nov 2026 03:42 |
| CERT Polska warning list | https://cert.pl/en/warning-list/ | CERT Polska terms | 14 Nov 2026 03:42 |
| Answers of public DNS resolvers | https://indahl.ai/cada | our own measurements | 14 Nov 2026 03:42 |
