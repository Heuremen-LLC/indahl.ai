# TIME Data Pack

Heuremen LLC · https://indahl.ai/time

As of 12 Nov 2026 00:13, the time stamped on the desk's feed when this pack was built.

## The question

Public time servers, stated against delivered. The page states it in full at https://indahl.ai/time.

## The ruler

Consistent: the offset and path uncertainty fit inside the stated bound. Above: the server is further from true time than it states. Below: it is closer than it states. Cannot tell: the path is wider than the bound. Nothing returned, refused and held are counted as their own outcomes. No ranking.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/time_outcomes.csv holds 36 rows: 34 CANNOT_TELL, 2 NOTHING_RETURNED.

## Files

- results/time_summary.json: the feed as served at https://indahl.ai/time/live.json when this pack was built.
- results/time_summary.csv: the same file flattened to one row per value, with its path.
- results/time_outcomes.json and results/time_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, ATLAS Data Pack, Zenodo, doi:10.5281/zenodo.23874305

https://doi.org/10.5281/zenodo.23874305

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
