# TIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 21:15 UTC and checked against the live feed at https://indahl.ai/time/live.json.

- holds: time_summary.csv: 660 rows, one per value of the live feed (660)
- holds: time_outcomes.csv: 36 rows, the live feed holds 36 results, outcome, n, lo and hi equal on every row
- holds: time_summary.json: byte for byte the live feed (sha256 90e722583d4172c3)

TESTED 2026-11-11 21:15 UTC: 3 checks, every one holds.
