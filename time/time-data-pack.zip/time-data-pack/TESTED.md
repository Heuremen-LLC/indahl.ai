# TIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 14:32 UTC and checked against the live feed at https://indahl.ai/time/live.json.

- holds: time_summary.csv: 658 rows, one per value of the live feed (658)
- holds: time_outcomes.csv: 36 rows, the live feed holds 36 results, outcome, n, lo and hi equal on every row
- holds: time_summary.json: byte for byte the live feed (sha256 57c781dae9ea2093)

TESTED 2026-11-11 14:32 UTC: 3 checks, every one holds.
