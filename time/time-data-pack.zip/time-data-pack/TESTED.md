# TIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 14:45 UTC and checked against the live feed at https://indahl.ai/time/live.json.

- holds: time_summary.csv: 661 rows, one per value of the live feed (661)
- holds: time_outcomes.csv: 36 rows, the live feed holds 36 results, outcome, n, lo and hi equal on every row
- holds: time_summary.json: byte for byte the live feed (sha256 6f1323005002a852)

TESTED 2026-11-12 14:45 UTC: 3 checks, every one holds.
