# TIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 22:47 UTC and checked against the live feed at https://indahl.ai/time/live.json.

- holds: time_summary.csv: 998 rows, one per value of the live feed (998)
- holds: time_outcomes.csv: 34 rows, the live feed holds 34 results, outcome, n, lo and hi equal on every row
- holds: time_summary.json: byte for byte the live feed (sha256 a83e3122383a6775)

TESTED 2026-11-12 22:47 UTC: 3 checks, every one holds.
