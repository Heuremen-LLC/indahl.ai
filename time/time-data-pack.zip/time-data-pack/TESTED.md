# TIME Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 10:54 UTC and checked against the live feed at https://indahl.ai/time/live.json.

- holds: time_summary.csv: 663 rows, one per value of the live feed (663)
- holds: time_outcomes.csv: 36 rows, the live feed holds 36 results, outcome, n, lo and hi equal on every row
- holds: time_summary.json: byte for byte the live feed (sha256 f74d37e327757a82)

TESTED 2026-11-12 10:54 UTC: 3 checks, every one holds.
