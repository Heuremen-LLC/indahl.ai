# TIME Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 13 Nov 2026 19:08, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| NTP replies of public time servers | https://indahl.ai/time | our own measurements | 13 Nov 2026 19:08 |
