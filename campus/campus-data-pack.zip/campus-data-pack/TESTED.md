# CAMPUS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 18:14 UTC and checked against the live feed at https://indahl.ai/campus/live.json.

- holds: campus_summary.csv: 212 rows, one per value of the live feed (212)
- holds: campus_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: campus_summary.json: byte for byte the live feed (sha256 8fe8643fd575ce2b)
- holds: page headline "272 of 308": 272 is in the pack
- holds: page headline "272 of 308": 308 is in the pack

TESTED 2026-11-12 18:14 UTC: 5 checks, every one holds.
