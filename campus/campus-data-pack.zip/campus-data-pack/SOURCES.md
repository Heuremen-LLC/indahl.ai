# CAMPUS Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 11 Nov 2026 18:15, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| School pages and documents cited on the OY page | https://indahl.ai/oy | each school keeps its rights. The pack holds only our status counts | 11 Nov 2026 18:15 |
