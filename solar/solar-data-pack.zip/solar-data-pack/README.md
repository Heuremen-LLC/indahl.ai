# SOLAR Data Pack

Heuremen LLC · https://indahl.ai/solar

As of 2026-11-12T05:43:09Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated flare and storm chances against what happened. The page states it in full at https://indahl.ai/solar.

## The ruler

A bin is a range of stated chance. Above means the event came more often than the mean stated chance in the bin, and below means less often, each by more than the 95% Wilson interval. Consistent means the mean stated chance is inside the interval. A bin with fewer than 30 days reads cannot tell. The Brier score is the mean squared gap between the stated chance and what happened. The skill compares it with always stating the base rate of the same days. Above zero is better than the base rate, and the skill reads consistent if its whole interval is within 0.05 of zero. The Wilson interval treats days as independent. They are not. Active regions and storms last for days, and the three days of one forecast share most of what the forecaster knew, so the Wilson interval can be too narrow. The effect is not the same everywhere. It is largest for M-class flares and high latitude storms, where the interval may be about one and a half times too narrow, and small for X-class flares and middle latitude storms. The skill interval is a moving block bootstrap over blocks of 27 days, one solar rotation, which keeps runs of days together. Each bin table also shows a block bootstrap interval beside the Wilson interval, as a description. The plan’s reading uses the Wilson interval. Stated as Class M. The event is a day with at least one flare of M1.0 or more at its peak. Not scored: 6 with no report on file, 13 issued after the day began, 2 with dates in the report that do not follow its own day, 1 with no events list for the day, 4 not yet settled. Stated as Class X. The event is a day with at least one flare of X1.0 or more at its peak. Not scored: 6 with no report on file, 13 issued after the day began, 2 with dates in the report that do not follow its own day, 1 with no events list for the day, 4 not yet settled. Stated as the minor storm chance plus the major or severe storm chance at middle latitudes, and adding them is our reading. The event is a day whose greatest Fredericksburg K is 5 or more. Not scored: 6 with no report on file, 13 issued after the day began, 2 with dates in the report that do not follow its own day, 68 with a missing K value, 4 not yet settled. The report names no station for its geomagnetic chances. Its Part V names Fredericksburg for the A index, and Fredericksburg is our reading here. The same stated chances read against SWPC’s estimated planetary K of 5- or more from the same daily data are in the table below. They sit close to what happened, so a below reading at Fredericksburg may say more about which index is meant than about the forecast. The planetary table is shown at the same size and decides nothing. Stated as the major or severe storm chance at middle latitudes. The event is a day whose greatest Fredericksburg K is 6 or more. Not scored: 6 with no report on file, 13 issued after the day began, 2 with dates in the report that do not follow its own day, 68 with a missing K value, 4 not yet settled. The report names no station for its geomagnetic chances. Its Part V names Fredericksburg for the A index, and Fredericksburg is our reading here. The same stated chances read against SWPC’s estimated planetary K of 6- or more from the same daily data are in the table below. They sit close to what happened, so a below reading at Fredericksburg may say more about which index is meant than about the forecast. The planetary table is shown at the same size and decides nothing. Stated as the minor storm chance plus the major or severe storm chance at high latitudes, and adding them is our reading. The event is a day whose greatest College K is 5 or more. Not scored: 6 with no report on file, 13 issued after the day began, 2 with dates in the report that do not follow its own day, 55 with a missing K value, 4 not yet settled. Stated as the major or severe storm chance at high latitudes. The event is a day whose greatest College K is 6 or more. Not scored: 6 with no report on file, 13 issued after the day began, 2 with dates in the report that do not follow its own day, 55 with a missing K value, 4 not yet settled. The tables for the second and third day are in the feed. These rows decide nothing. The report names no station or index for its geomagnetic chances. Against SWPC’s estimated planetary K and against the planetary Kp from GFZ Potsdam the middle latitude storm chances sit closer to what happened than against Fredericksburg K. That does not say which index SWPC means. The most recent GFZ values are nowcast values and may be replaced by definitive ones.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/solar_outcomes.csv holds 280 rows: 116 CANNOT_TELL, 64 BELOW, 62 CONSISTENT, 38 ABOVE.

## Files

- results/solar_summary.json: the feed as served at https://indahl.ai/solar/live.json when this pack was built.
- results/solar_summary.csv: the same file flattened to one row per value, with its path.
- results/solar_outcomes.json and results/solar_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, ATLAS Desk Packs, Zenodo, doi:10.5281/zenodo.24118626

https://doi.org/10.5281/zenodo.24118626

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
