# SOLAR Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 16:11 UTC and checked against the live feed at https://indahl.ai/solar/live.json.

- holds: solar_summary.csv: 3135 rows, one per value of the live feed (3135)
- holds: solar_outcomes.csv: 271 rows, the live feed holds 271 results, outcome, n, lo and hi equal on every row
- holds: solar_summary.json: byte for byte the live feed (sha256 f209a5ae2ed2a0c7)
- holds: page headline "4 of 8": 4 is in the pack
- holds: page headline "4 of 8": 8 is in the pack

TESTED 2026-11-10 16:11 UTC: 5 checks, every one holds.
