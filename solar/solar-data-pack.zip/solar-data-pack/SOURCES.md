# SOLAR Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-11T18:42:18Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| NOAA SWPC Report and Forecast of Solar and Geophysical Activity (Warehouse, as first published) | ftp://ftp.swpc.noaa.gov/pub/warehouse/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-11T18:42:18Z |
| NOAA SWPC Edited Solar Events, Daily Geomagnetic Data, Daily Solar Data | ftp://ftp.swpc.noaa.gov/pub/indices/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-11T18:42:18Z |
| GFZ Potsdam Kp index (Kp only, no sunspot numbers) | https://kp.gfz.de/ | CC BY 4.0, Matzka et al. 2021, doi 10.1029/2020SW002641, data doi 10.5880/Kp.0001 | 2026-11-11T18:42:18Z |
