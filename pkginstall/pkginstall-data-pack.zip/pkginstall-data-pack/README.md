# PKGINSTALL Data Pack

Heuremen LLC · https://indahl.ai/pkginstall

As of 11 Nov 2026 18:42, the time stamped on the desk's feed when this pack was built.

## The question

Install commands against pip resolution. The page states it in full at https://indahl.ai/pkginstall.

## The ruler

Agree: pip would install the command. Disagree: pip fails because a target is not on PyPI, the requirements conflict, or no version matches although the project has a wheel that fits. Above: the lower end of the 95 percent interval of the failing share is above 0.10. Consistent: the upper end is below 0.05. Otherwise, and with fewer than 30 comparable projects, cannot tell. Source: the PyPI JSON API and pip.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/pkginstall_outcomes.csv holds 1 row: 1 CONSISTENT.

## Files

- results/pkginstall_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/pkginstall_summary.csv: the same file flattened to one row per value, with its path.
- results/pkginstall_outcomes.json and results/pkginstall_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because PyPI metadata is under the PyPI terms of service and not an open licence.

## Cite

Heuremen LLC, IRIS Desk Packs, Zenodo, doi:10.5281/zenodo.24110664

https://doi.org/10.5281/zenodo.24110664

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
