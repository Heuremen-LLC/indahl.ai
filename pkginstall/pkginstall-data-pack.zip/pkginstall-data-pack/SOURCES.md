# PKGINSTALL Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 13 Nov 2026 12:00, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| PyPI JSON API | https://docs.pypi.org/api/json/ | PyPI terms of service | 13 Nov 2026 12:00 |
| Top PyPI Packages | https://hugovk.github.io/top-pypi-packages/ | public list | 13 Nov 2026 12:00 |
