# CHANGE Data Pack

Heuremen LLC · https://indahl.ai/change

As of 12 Nov 2026 01:17, the time stamped on the desk's feed when this pack was built.

## The question

Announced shutdown dates, kept over time. The page states it in full at https://indahl.ai/change.

## The ruler

Held: a stated date passed and never changed while we watched. Moved: it changed at least once before it passed. Removed early: the row left the page before its date. Fewer than 30 dates in the test reads cannot tell. Notice is the days from a stated deprecation date to the shutdown date. Lifespan is the days from release to shutdown and is not notice. Google names that contain preview are shown apart from the other names. Sources are the vendors' own deprecation pages, linked in the code folder.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/change_outcomes.csv holds 1 row: 1 CANNOT_TELL.

## Files

- results/change_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/change_summary.csv: the same file flattened to one row per value, with its path.
- results/change_outcomes.json and results/change_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because the vendor pages carry mixed terms and one bars automated copying.

## Cite

Heuremen LLC, ATLAS Data Pack, Zenodo, doi:10.5281/zenodo.23874305

https://doi.org/10.5281/zenodo.23874305

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
