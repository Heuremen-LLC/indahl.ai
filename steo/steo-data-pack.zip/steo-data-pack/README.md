# STEO Data Pack

Heuremen LLC · https://indahl.ai/steo

As of 2026-11-11T20:53:40Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated energy price intervals against the spot price. The page states it in full at https://indahl.ai/steo.

## The ruler

One row is one issue, one price and one month. Inside means the monthly average spot price is at or between the two stated bounds. Above and below are printed apart, and a 95 percent interval leaves about 2.5 percent on each side. Rows are not independent. Many issues state an interval for the same month, and prices in neighbouring months move together. So the interval is a moving-block bootstrap over outcome months, in blocks of 12 consecutive months, 2,000 draws, and it is much wider than one that treats rows as independent. Reading: below if the whole interval is under 95 percent, above if it is over, consistent if 95 percent is inside an interval no wider than 15 points, otherwise cannot tell. A cell needs 30 scored rows and 24 outcome months. Tried after the data with blocks of 6 and 24 months, the plan’s readings do not change. In this second reading WTI all leads reads consistent with blocks of 6 months and cannot tell with blocks of 24, and Henry Hub all leads reads below and cannot tell.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/steo_outcomes.csv holds 42 rows: 25 CANNOT_TELL, 16 CONSISTENT, 1 BELOW.

## Files

- results/steo_summary.json: the feed as served at https://indahl.ai/steo/live.json when this pack was built.
- results/steo_summary.csv: the same file flattened to one row per value, with its path.
- results/steo_outcomes.json and results/steo_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
