# STEO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 14:00 UTC and checked against the live feed at https://indahl.ai/steo/live.json.

- holds: steo_summary.csv: 715 rows, one per value of the live feed (715)
- holds: steo_outcomes.csv: 42 rows, the live feed holds 42 results, outcome, n, lo and hi equal on every row
- holds: steo_summary.json: byte for byte the live feed (sha256 21008c79b33de641)
- holds: page headline "392 of 452": 392 is in the pack
- holds: page headline "392 of 452": 452 is in the pack

TESTED 2026-11-11 14:00 UTC: 5 checks, every one holds.
