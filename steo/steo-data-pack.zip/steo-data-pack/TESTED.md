# STEO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 16:20 UTC and checked against the live feed at https://indahl.ai/steo/live.json.

- holds: steo_summary.csv: 873 rows, one per value of the live feed (873)
- holds: steo_outcomes.csv: 43 rows, the live feed holds 43 results, outcome, n, lo and hi equal on every row
- holds: steo_summary.json: byte for byte the live feed (sha256 b35526e4d82827f4)
- holds: page headline "392 of 452": 392 is in the pack
- holds: page headline "392 of 452": 452 is in the pack

TESTED 2026-11-12 16:20 UTC: 5 checks, every one holds.
