# STEO Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-11T20:53:40Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| EIA Short-Term Energy Outlook chart gallery workbooks (Internet Archive copies) | https://www.eia.gov/outlooks/steo/ | U.S. government work, public domain (17 U.S.C. 105). Interval inputs credited by EIA to CME Group, Bloomberg, L.P., and Refinitiv an LSEG Business | 2026-11-11T20:53:40Z |
| EIA monthly spot prices RWTC and RNGWHHD | https://www.eia.gov/dnav/pet/hist/LeafHandler.ashx?n=PET&s=RWTC&f=M | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-11T20:53:40Z |
