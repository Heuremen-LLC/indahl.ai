# FLU Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 23:13 UTC and checked against the live feed at https://indahl.ai/flu/live.json.

- holds: flu_summary.csv: 7300 rows, one per value of the live feed (7300)
- holds: flu_outcomes.csv: 284 rows, the live feed holds 284 results, outcome, n, lo and hi equal on every row
- holds: flu_summary.json: byte for byte the live feed (sha256 5056291df9f0f26d)
- holds: page headline "16,629 of 18,756": 16,629 is in the pack
- holds: page headline "16,629 of 18,756": 18,756 is in the pack

TESTED 2026-11-13 23:13 UTC: 5 checks, every one holds.
