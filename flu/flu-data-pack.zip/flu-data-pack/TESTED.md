# FLU Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 21:15 UTC and checked against the live feed at https://indahl.ai/flu/live.json.

- holds: flu_summary.csv: 5555 rows, one per value of the live feed (5555)
- holds: flu_outcomes.csv: 283 rows, the live feed holds 283 results, outcome, n, lo and hi equal on every row
- holds: flu_summary.json: byte for byte the live feed (sha256 6d051b9083596f12)
- holds: page headline "16,416 of 18,544": 16,416 is in the pack
- holds: page headline "16,416 of 18,544": 18,544 is in the pack

TESTED 2026-11-11 21:15 UTC: 5 checks, every one holds.
