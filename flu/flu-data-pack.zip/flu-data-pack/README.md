# FLU Data Pack

Heuremen LLC · https://indahl.ai/flu

As of 2026-11-13T08:52:05Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated flu forecast intervals against reported admissions. The page states it in full at https://indahl.ai/flu.

## The ruler

One row is one forecast: a place, a week and a horizon. The places are the United States as a whole, the 50 states, Washington DC and Puerto Rico. Inside means the reported count is at or between the two stated quantiles. Above and below are printed apart, and a well-calibrated interval leaves about the same share on each side. Cannot tell is never folded into either side. Rows are not independent. Every place in a week shares one flu season, and forecasts made at different horizons share target weeks. So the interval is a moving-block bootstrap over target weeks, in blocks of 4 consecutive weeks, 2,000 draws, and it is much wider than an interval that treats rows as independent. Reading: below if the whole interval is under the stated level, above if it is over it, otherwise cannot tell (STRADDLES_EDGE) because the interval holds the stated level. The plan named no tolerance around the stated level, so no cell reads consistent (plan addendum of 12 November 2026, Faults and Guards 2.0). A cell needs 30 scored rows and 8 target weeks, and with fewer it reads cannot tell (TOO_WIDE_TO_RESOLVE). The block length was fixed in the plan. Tried after the data, longer blocks widen the all-horizons interval for the outer interval to 79.9 to 94.9 percent with blocks of 8 weeks and 79.1 to 95.3 percent with blocks of 13 weeks, which read below and cannot tell (STRADDLES_EDGE). Of 18,020 rows with both counts, the first reported and latest counts differ in 13,266, by a median of 8 admissions where they differ. A row whose earliest release came more than 14 days after the week reads cannot tell on this side. In the all-horizons cell that is 530 rows. The interval is the same block bootstrap. Reading: below if the whole interval is under 1, above if over 1, otherwise cannot tell (STRADDLES_EDGE). The plan named no tolerance around 1, so no cell reads consistent.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/flu_outcomes.csv holds 284 rows: 227 CANNOT_TELL, 54 BELOW, 1 ABOVE.

## Files

- results/flu_summary.json: the feed as served at https://indahl.ai/flu/live.json when this pack was built.
- results/flu_summary.csv: the same file flattened to one row per value, with its path.
- results/flu_outcomes.json and results/flu_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
