# FLU Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-13T11:07:49Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| CDC FluSight Forecast Hub (FluSight-ensemble, FluSight-baseline, NHSN target data) | https://github.com/cdcepi/FluSight-forecast-hub | repository MIT licence, FluSight-ensemble CC BY 4.0 (credit the CDC FluSight team and UMass Amherst), NHSN data U.S. government work | 2026-11-13T11:07:49Z |
