# HOSTS Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 14 Nov 2026 10:43, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| OpenRouter models and endpoints API | https://openrouter.ai/docs | OpenRouter terms of service | 14 Nov 2026 10:43 |
