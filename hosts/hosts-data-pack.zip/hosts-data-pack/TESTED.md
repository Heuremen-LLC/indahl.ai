# HOSTS Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 16:34 UTC and checked against the live feed at https://indahl.ai/hosts/live.json.

- holds: hosts_summary.csv: 143 rows, one per value of the live feed (143)
- holds: hosts_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "47": 47 is in the pack

TESTED 2026-11-11 16:34 UTC: 3 checks, every one holds.
