# SOCIAL Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 13:44 UTC and checked against the live feed at https://indahl.ai/social/summary.json.

- holds: dsa: summary file sha256 equals the sha256 the live /social/summary.json names
- holds: adspend: summary file sha256 equals the sha256 the live /social/summary.json names
- holds: tiktok: summary file sha256 equals the sha256 the live /social/summary.json names
- holds: bluesky: summary file sha256 equals the sha256 the live /social/summary.json names
- holds: social_summary.csv: 195 rows, one per value of the live feed (195)
- holds: social_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: social_summary.json: byte for byte the live feed (sha256 38e20ac165a6f321)
- holds: dsa_summary.csv: 698 rows, one per value of the live feed (698)
- holds: dsa_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: adspend_summary.csv: 596 rows, one per value of the live feed (596)
- holds: adspend_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: tiktok_summary.csv: 629 rows, one per value of the live feed (629)
- holds: tiktok_outcomes.csv: 128 rows, the live feed holds 128 results, outcome, n, lo and hi equal on every row
- holds: bluesky_summary.csv: 90 rows, one per value of the live feed (90)
- holds: bluesky_outcomes.csv: 26 rows, the live feed holds 26 results, outcome, n, lo and hi equal on every row
- holds: dsa_rows.json: byte for byte the live /social/dsa.json
- holds: dsa_rows.csv: 519 rows with an outcome, the live summary counts 519
- holds: dsa_rows.csv: outcome counts {'CANNOT_TELL': 330, 'CONSISTENT': 41, 'ABOVE': 39, 'BELOW': 82, 'NOTHING_RETURNED': 27} equal the live summary

TESTED 2026-11-10 13:44 UTC: 18 checks, every one holds.
