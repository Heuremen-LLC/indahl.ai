# SOCIAL Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-12 15:55 UTC, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Platform DSA transparency reports (Implementing Regulation 2024/2835 template) | https://digital-strategy.ec.europa.eu/en/policies/dsa-impl-reg-transparency-reporting | mandatory public reports, figures quoted, each platform keeps its rights | 2026-11-12 15:55 UTC |
| EU DSA Transparency Database, complete monthly aggregates | https://transparency.dsa.ec.europa.eu/explore-data/download | CC BY 4.0 | 2026-11-12 15:55 UTC |
| Google political ads transparency bundle | https://adstransparency.google.com/terms | Google terms, information or research purposes only | 2026-11-12 15:55 UTC |
| FEC bulk data | https://www.fec.gov/data/browse-data/?tab=bulk-data | U.S. government work, public domain (17 U.S.C. 105). Individual contributor files were never read | 2026-11-12 15:55 UTC |
| TikTok Community Guidelines Enforcement Report | https://www.tiktok.com/safety/en/transparency/cg-report | TikTok terms | 2026-11-12 15:55 UTC |
| EU DSA Transparency Database aggregates (TikTok) | https://transparency.dsa.ec.europa.eu/explore-data/download | CC BY 4.0 | 2026-11-12 15:55 UTC |
| Bluesky 2025 Transparency Report | https://bsky.social/about/blog/01-29-2026-transparency-report-2025 | Bluesky keeps its rights, figures quoted | 2026-11-12 15:55 UTC |
| Bluesky moderation label stream | https://indahl.ai/social | open protocol endpoint, no terms stated | 2026-11-12 15:55 UTC |

Each row of results/dsa_rows.json names its own source report in the sources block of that file.
