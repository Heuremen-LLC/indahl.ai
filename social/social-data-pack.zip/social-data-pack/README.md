# SOCIAL Data Pack

Heuremen LLC · https://indahl.ai/social

As of 2026-11-10 12:34 UTC, the time stamped on the desk's feed when this pack was built.

## The question

Platform reports against the filings. The page states it in full at https://indahl.ai/social.

## The ruler

Each count is the outcome printed on the row in its section. Rows read with a rule set after the data say so in their section and are counted as printed. The TikTok column of readings defined after the data is not counted here. Where a row rests on a platform’s own note on a field, the note is quoted here, from the report: For YouTube, Google Maps and Google Play these rows count only statements not flagged as ads, against the main report files. Facebook and Instagram each say some actions are reported for both services combined, so their own rows read cannot tell. The combined row reads both services together and also reads cannot tell. Both reports build their totals as sums of restriction columns, so the combined lower edge is the larger of the two services’ largest columns, and that leaves every combined band too wide to read. Solely automated is read against statements marked fully automated, and not automated against statements marked not automated. The database also has a partially automated category with no field in the report, so those statements are added to the upper edge of both bands. Stated zero: consistent if the database holds none, above if it holds at least 100 statements across the whole band. One row per matched committee, or group of committees that Google’s file joins, and cycle. The 2026 cycle runs to 30 June 2026, the end of the last full month in the FEC’s itemized file on the day we read it. Most rows read Cannot tell. The commonest reasons are a timing band wider than a factor of two (2,322 rows) and purchases through others that could close the gap (2,245 rows). Nothing returned: Google states spend in the window and the FEC files hold no row and no summary for the committee in that cycle. Band: the spend that must have been paid inside the window to the spend that could have been, allowing payments 31 days before to 92 days after each ad week and 100 dollars either way per week for Google’s rounding to whole hundreds. It is a bound, not a confidence interval. Ad rows leave out amounts that a filer marked as estimates in 24- or 48-hour reports. All rows count them. Above: ad payments to Google exceed the top of the band by at least 1,000 dollars and 10 percent, and Google lists spend in the window. Below: every payment to Google, every payment to others for ads, digital or media, and any money in the committee’s own summary that the itemized file does not hold, all together, fall short of the bottom of the band by that much, and the gap does not rest on a name match alone. Consistent: ad payments to Google reach the bottom of the band, every payment to Google plus that unseen money stays under its top, and the band spans no more than a factor of two. Unseen money counts in full for party committees and for committees whose itemized file holds less than nine tenths of their own operating disbursements. Otherwise it counts up to 400 dollars, the most the itemization rule can leave unitemized for one payee over two years (200 dollars a calendar year, or 200 dollars an election cycle for a candidate’s committee). That rule and its threshold were defined after the data, and rows whose outcome depends on it say so. Cannot tell: anything else. Agency means payments to others for ads, digital or media could close the gap. Band means the timing band spans more than a factor of two. Purpose means rows of unclear purpose decide the side. Unseen means money that the itemized file does not hold could decide it. Near means the gap is under the size that matters. Scope means the filer type reports no operating expenditures. Cycle means the committee is not registered in that cycle, or its candidate was not a candidate then. Name means the reading would rest on an advertiser matched by name alone. No Google spend means Google lists no election-ad spend for the advertiser in the window. Estimates means the reading rests on amounts the filer marked as estimates. Depends on timing means a wider band of 92 days before and 183 days after gives another outcome. Other notes on a row keep its outcome and say what could move it. Google figures are from its weekly spend file. FEC figures are from Schedule B operating expenditures, the independent expenditure file and the summary files. Bluesky states: the figure as printed in Bluesky’s report, quoted with its source line in bluesky.json. Stream, first reading: labels the stream serves today with a creation time in the UTC calendar year, negated labels left out. Range across our counting rules: the lowest to the highest count over the readings fixed in our plan. The readings are the first reading, the same by the US Pacific year, the same by position in the stream’s sequence, the first reading with negations dated in the year added, the first reading with later negations each credited with one label in the year, the first reading with labels on the same subject and value counted once, and the sequence-position reading with every sequence number of the year that the stream no longer serves credited to the row. The range is the spread of these rules, not a sampling interval, since every count is exact. Above means the whole range is above the stated figure, below means the whole range is below it, consistent means the whole range sits inside the stated figure’s rounding, and cannot tell means neither. For takedowns only a stream count above the stated figure can be read, since takedowns can be made outside the stream. Outcomes in this table: below 1, cannot tell 25.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/social_outcomes.csv holds 0 rows, each with an interval and no outcome word.
results/dsa_outcomes.csv holds 0 rows, each with an interval and no outcome word.
results/adspend_outcomes.csv holds 0 rows, each with an interval and no outcome word.
results/tiktok_outcomes.csv holds 128 rows: 119 CANNOT_TELL, 9 ABOVE.
results/bluesky_outcomes.csv holds 26 rows: 25 CANNOT_TELL, 1 BELOW.

## Files

- results/social_summary.json: the feed as served at https://indahl.ai/social/summary.json when this pack was built.
- results/social_summary.csv: the same file flattened to one row per value, with its path.
- results/social_outcomes.json and results/social_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/dsa_summary.json: the section summary the page is built from, byte for byte.
- results/dsa_summary.csv: the same file flattened to one row per value, with its path.
- results/dsa_outcomes.json and results/dsa_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/adspend_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/adspend_summary.csv: the same file flattened to one row per value, with its path.
- results/adspend_outcomes.json and results/adspend_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/tiktok_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/tiktok_summary.csv: the same file flattened to one row per value, with its path.
- results/tiktok_outcomes.json and results/tiktok_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/bluesky_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/bluesky_summary.csv: the same file flattened to one row per value, with its path.
- results/bluesky_outcomes.json and results/bluesky_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- results/dsa_rows.json and results/dsa_rows.csv: one row per item the desk reads, as served at https://indahl.ai/social/dsa.json.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The DSA section carries the published rows, whose platform figures are quoted from mandatory public reports and whose database figures are CC BY 4.0. The adspend section carries only our derived results (counts, outcomes and intervals) and links to its sources, because Google limits the Ads Transparency Center to information or research purposes and bars monetising it. The tiktok section carries only our derived results (counts, outcomes and intervals) and links to its sources, because TikTok terms bar automated extraction from its platform. The bluesky section carries only our derived results (counts, outcomes and intervals) and links to its sources, because Bluesky states no reuse terms for its report or its label stream.
