# CADENCE Data Pack

Heuremen LLC · https://indahl.ai/cadence

As of 13 Nov 2026 16:19, the time stamped on the desk's feed when this pack was built.

## The question

Stated update schedules against delivered. The page states it in full at https://indahl.ai/cadence.

## The ruler

The modified date is what the publisher reports. On a sample of each portal's download links, the file's own date is compared with it and shown. Series with a cadence that is not a regular interval, or with no readable date, are counted as cannot tell (NO_INTERVAL_FORMABLE), since no margin can be formed. A portal whose file could not be read is listed apart and is in no share. A stated duration may carry a decimal, so R/P3.5D is 3.5 days, and when records of one series share the newest date and state different cadences, the series is read against the longest of them. Both rules were written on 10 November 2026, after the data, and the count under the old rules is shown beside the total (plan addendum 2). No ranking of agencies.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/cadence_outcomes.csv holds 8 rows, each with an interval and no outcome word.

## Files

- results/cadence_summary.json: the feed as served at https://indahl.ai/cadence/live.json when this pack was built.
- results/cadence_summary.csv: the same file flattened to one row per value, with its path.
- results/cadence_outcomes.json and results/cadence_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
