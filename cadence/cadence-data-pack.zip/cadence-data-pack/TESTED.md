# CADENCE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 19:59 UTC and checked against the live feed at https://indahl.ai/cadence/live.json.

- holds: cadence_summary.csv: 467 rows, one per value of the live feed (467)
- holds: cadence_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: cadence_summary.json: byte for byte the live feed (sha256 8ef109faca223c4b)
- holds: page headline "nearly 16 years": 16 is in the pack

TESTED 2026-11-11 19:59 UTC: 4 checks, every one holds.
