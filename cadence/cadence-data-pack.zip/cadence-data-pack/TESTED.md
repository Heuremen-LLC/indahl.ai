# CADENCE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 14:31 UTC and checked against the live feed at https://indahl.ai/cadence/live.json.

- holds: cadence_summary.csv: 467 rows, one per value of the live feed (467)
- holds: cadence_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: cadence_summary.json: byte for byte the live feed (sha256 a73b5be8f1832e8c)
- holds: page headline "nearly 16 years": 16 is in the pack

TESTED 2026-11-11 14:31 UTC: 4 checks, every one holds.
