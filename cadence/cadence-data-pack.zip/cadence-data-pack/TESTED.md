# CADENCE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 13:36 UTC and checked against the live feed at https://indahl.ai/cadence/live.json.

- holds: cadence_summary.csv: 461 rows, one per value of the live feed (461)
- holds: cadence_outcomes.csv: 0 rows, the live feed holds 0 results, outcome, n, lo and hi equal on every row
- holds: cadence_summary.json: byte for byte the live feed (sha256 f67b07fb8dbd1c8e)
- holds: page headline "16 years": 16 is in the pack

TESTED 2026-11-10 13:36 UTC: 4 checks, every one holds.
