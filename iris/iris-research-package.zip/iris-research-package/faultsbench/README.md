# Faults and Guards bench: scorer and planted items

Heuremen LLC. `items.json` holds the planted items, each with its own truth. `score.py` scores replies written as `out/<model>/<arm>.jsonl` (arms bare, bare_copy and guard, one JSON object per line with id, raw and done_reason) and writes `results.json`. `synth.py` runs the scorer on planted worlds and asserts the expected outcomes. Run it from inside this folder, because it reads `items.json` and imports `score.py` from the current folder.

```
cd faultsbench
python synth.py
```

The prompts (`items.py`), the runner and the plan are in the repository: https://github.com/Heuremen-LLC/indahl.ai/tree/main/code/iris/faultsbench
