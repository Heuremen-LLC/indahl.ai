# IRIS Failure-Mode Matrix (internal nickname "Matrix of Shame"; public title his call): failure modes x open-weight models. Plan committed before any call.
Seats: our own Ollama on 127.0.0.1:11500, models in iris_index/seats/models (fresh stock pulls; never ~/.ollama/models, never Nova's
server). One model loaded, one request at a time, num_ctx 4096, temperature 0, seed 20261025, format=json, think=false where supported.
Inputs (frozen, public, released with gold): inputs/nep_gold.csv (NepPlural 300, gold No-Persona 116 / persona 184) with their abstention
system prompt verbatim; inputs/mcq_200.json (Jev-ToM release: 100 ToMi + 100 BigToM, 2 options each, gold index).
Every call logs its terminating reason; outcomes per call: PARSED / UNPARSED / EMPTY / ERROR (four, never folded).
## Rows (each arm can produce the outcome it is scored on: referee rule 4)
M1 OVER-ATTRIBUTION (forced-verdict family): abstain prompt; share of the 116 gold No-Persona comments given a persona anyway. Beside it,
   the other alternative: false abstention on the 184 persona comments. Both printed (EL FILTRO: both alternatives).
M2 COPY FLOOR (known-good): the abstain arm repeated identically; disagreement share of the label tuple. MCQ single arm repeated
   identically; disagreement share of the chosen option. KNOWN-GOOD RULE: MCQ copy agreement >= 95% or that model's M3-M6 are CANNOT_TELL.
M3 OPTION-ORDER CARRIER: MCQ with options reversed; flip share of the chosen CONTENT and paired accuracy change, read against M2's floor.
M4 BATCH CARRIER: MCQ in batches of 8 (25 calls) vs single; agreement of chosen content with single minus the single copy agreement.
M5 FORMAT CARRIER: template B ("Reply with the letter only") vs template A (story, question, options, JSON answer); paired accuracy change.
M6 SELF-COUNT FROM MEMORY: each batch-8 call also asks "how many of your answers in this reply were option A?"; share of calls whose
   stated count differs from the model's own answers in that same reply.
## Statistics: item bootstrap (2,000, seed 20261025); cluster = item (MCQ question / comment); M4/M6 cluster = batch. Four outcomes per cell
   against the cell's own floor. Multiplicity printed with the matrix: expected false calls = 0.05 x number of resolved-or-not cells.
   Marginal = interval bound within 0.01 of the floor: printed as MARGINAL beside the outcome (referee rule 1).
## Synth first: synth_matrix.py plants worlds (null: no carrier; carrier only; over-attribution only; copies disagree) through
   score_matrix.py; the plan's outcomes must come back on each planted world before any model is run.
KNOWN-GOOD: identical MCQ copies agree on >= 95% of items, or that model's carrier cells are CANNOT_TELL. Synth: synth_results.text (planted
worlds recovered: null CONSISTENT; order and batch carriers ABOVE; copies-disagree -> CANNOT_TELL; over-attribution 0.60 recovered;
self-count planted 0.8 recovered). CODE hashes in CODE.sha256. Synth caveat: the generator redraws the NepPlural copy, so its planted
nep copy floor is not zero in the over-attribution world; the scorer is unaffected.
ADDENDUM (25 Oct, before reading any model but gemma3's terminations): batches dropped from M4/M6 are counted by reason in M4_M6_batches_dropped; a model with more than 5 of 25 dropped has M4/M6 marked CANNOT_TELL in MATRIX.md.
ADDENDUM 2 (25 Oct, DEFINED AFTER SEEING qwen3's replies): a reply that parses as JSON but has no "answer" field is its own termination,
NO_ANSWER_FIELD (qwen3 echoed the input in 193/200 MCQ calls under format=json, think=false). A model above 10% NO_ANSWER_FIELD has all MCQ
cells CANNOT_TELL; its NepPlural cells stand if those replies carry the asked fields (checked: all four complete models do). Wrong-length
batch replies are reported as M6b (answered a different number of items than asked) beside the CANNOT_TELL on M4/M6.

## Addendum 3 (25 Oct ~10:20; after the v1b referee, BEFORE any rescored output is read). Corrections, not new analyses:
 a. Answer parsing (v1 and v2 scorers): an answer counts only if it is a bare option letter (any case), or a letter followed by
    ".", ")", ":" or a space (e.g. "A. suitcase"), or an exact (case-insensitive, trimmed) match to one option's text, mapped to that
    option. Anything else is UNPARSED. (Was: first character of any string, which read "box"/"bathtub" as B and "attic" as A.)
 b. NepPlural drop share: if more than 10% of a model's NepPlural replies are unparsed or truncated (done_reason=length), its M1 cells
    print CANNOT_TELL (partial: k of n usable); M1 cells always print n of the gold denominator.
 c. Known-good (determinism) needs >= 150 usable copy pairs AND <= 5% disagreement (the n clause was in the scorer, now stated here);
    a FAIL prints its reason (too few usable pairs vs disagreement).
 d. Batch drop reasons name the format: "item-keyed dict" when answers is a dict; the dict-parsed values are printed as a labelled
    bound, outcome stays CANNOT_TELL (plan: list format required).
 e. Bootstrap reseeded with 20261025 inside every interval call (per-cell reproducible); matrix_results.json outcomes masked as in MATRIX.md.
 f. Footer counts only resolved carrier cells for expected false calls.
Every cell whose value or outcome changes under (a)-(f) prints the old value beside the new.
