# IRIS List Pack

Heuremen LLC. The IRIS List in files you can open in a spreadsheet, a reference manager or a LaTeX project. Page: https://indahl.ai/iris/list

## Files

- `list.json`: The List as published at https://indahl.ai/iris/list, unchanged. Top-level keys are note, terms and studies.
- `list.csv`: One row per study, with every field of list.json. The receipt lines are joined with a vertical bar. The column indahl_url points to the study on the List page. The list.json rows carry no anchor, so the anchor column is built from the arXiv number as arxiv-<number> without the version.
- `KEY.csv`: The codes and what they mean, copied from https://indahl.ai/iris/key.
- `references.bib`: One BibTeX entry for each study on the List. These are other people's papers. Each entry carries the title and link as listed, the arXiv number or DOI when the link holds one, and a note that points to the List. No authors or years are given because the List does not carry them.
- `references.ris`: The same entries in RIS format.
- `CITE_THE_LIST.bib`: One BibTeX entry for the IRIS List itself.
- `CITATION.cff`: Citation file for the List.
- `verify.py`: Checks that the files agree with each other. Run python3 verify.py in this folder.
- `LICENSE.txt`: Terms for this data.
- `START_HERE.html`: This page.

A title that starts with a minus sign can be read as a formula by a spreadsheet, so import list.csv as text.

## Codes

The codes are explained in KEY.csv and at the key page: https://indahl.ai/iris/key

## Import

- Zotero: choose File, then Import, and select references.bib or references.ris.
- BibTeX or LaTeX: copy references.bib next to your document and cite an entry with its key, for example `\cite{iris-arxiv-2610.26828}`. To cite the List itself use CITE_THE_LIST.bib. Titles are UTF-8 and some hold Greek, Cyrillic or math characters, so use biber with LuaLaTeX or XeLaTeX, or a recent LaTeX with UTF-8 input.
- Spreadsheet: open list.csv. It is UTF-8 with a header row. In Excel use Data, then From Text/CSV, and pick UTF-8.

## Terms

Free to download and cite with attribution. All rights reserved. Text and data mining and use as AI training data are not permitted: https://indahl.ai/terms#ai-training

Each listed study keeps its own terms. Names appear as published. To have a name or a study removed: https://indahl.ai/contact

## Check

Run `python3 verify.py` in this folder. It compares the row counts of list.json, list.csv, references.bib and references.ris, checks the BibTeX braces and keys, and checks that every link starts with https://

## More

The site: https://indahl.ai

Code: https://github.com/Heuremen-LLC/indahl.ai

Built 2026-11-01.
