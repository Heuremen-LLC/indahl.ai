# REVISE Data Pack

Heuremen LLC · https://indahl.ai/revise

As of 13 Nov 2026 18:29, the time stamped on the desk's feed when this pack was built.

## The question

Stated margin against later revision. The page states it in full at https://indahl.ai/revise.

## The ruler

Above: the lower end of the exceedance share is above 0.10, the share a 90-percent interval would leave. Below: the upper end is below 0.10. Otherwise cannot tell (STRADDLES_EDGE). The figure 0.10 has no tolerance, so no count reads consistent (plan addendum of 12 November 2026). Until then the plan read consistent when 0.10 sat inside an interval no wider than 0.12, and the third-release count was recorded consistent on 10 November 2026 under that rule. The outcome column uses the interval over months, the interval the plan names. The interval over calendar years treats each year as one unit, because the months of a year share a benchmark and consecutive months are not independent. It was defined after the first read and is shown with the outcome the same rule would give for it. Beside each count the page prints the number of failed reads and the share of cannot tell among the two readings, split by reason. Signed revisions are later minus first, in thousands of jobs. Sources: the BLS revisions table, the BLS payroll series and the BLS technical note.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/revise_outcomes.csv holds 2 rows: 1 CANNOT_TELL, 1 ABOVE.

## Files

- results/revise_summary.json: the feed as served at https://indahl.ai/revise/live.json when this pack was built.
- results/revise_summary.csv: the same file flattened to one row per value, with its path.
- results/revise_outcomes.json and results/revise_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
