# NEO Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-11T12:10:26Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| NASA/JPL SBDB Close-Approach Data API | https://ssd-api.jpl.nasa.gov/doc/cad.html | JPL SSD API, no reuse licence stated, fair use policy https://ssd-api.jpl.nasa.gov/doc/index.php | 2026-11-11T12:10:26Z |
| NASA/JPL SBDB API | https://ssd-api.jpl.nasa.gov/doc/sbdb.html | JPL SSD API, no reuse licence stated | 2026-11-11T12:10:26Z |
| Internet Archive Wayback Machine copies of the Close-Approach service | https://web.archive.org/ | Internet Archive terms of use, https://archive.org/about/terms.php | 2026-11-11T12:10:26Z |
