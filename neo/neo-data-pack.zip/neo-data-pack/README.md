# NEO Data Pack

Heuremen LLC · https://indahl.ai/neo

As of 2026-11-12T05:43:09Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated asteroid close-approach distances against the later record. The page states it in full at https://indahl.ai/neo.

## The ruler

One row is one object and one approach inside 0.05 au since 1 January 2024, taken from the earliest copy that shows it before the approach. An object is counted once in a cell. Inside means the whole 3-sigma range of the latest solution lies inside the range stated earlier. Farther and closer mean the whole latest range lies outside it. Judged on the later nominal distance alone, counting the rows that cross an edge, 503 of 519 are inside, which reads the same. This was added after the data. Cannot tell is never folded into either side. In the first row it holds 166 where the stated solution is still the latest one, 38 where the latest range crosses an edge of the stated range, 21 where the stated range is wider than 0.05 au, 1 where no current record of the approach was found. The interval is a 95% Wilson interval. Reading: below if the upper bound is under 99.7 percent, consistent if the lower bound is 98 percent or more, otherwise cannot tell. At this sample size a cell can read consistent only if nearly every row is inside. It takes about 190 scored rows, all inside, for the lower bound to reach 98 percent. The interval treats rows as independent. Rows from one copy share one moment of JPL's data, so the interval can be too narrow. The shift is the move of the nominal distance divided by one sixth of the stated range. It describes the move and is not a test. In 11 of these 14 rows the nominal distance moved by less than 2,000 km. 11 of the 14 stated ranges were under 1,000 km wide. Each stated copy links to the archived response. Solution shows the orbit ID the range was stated from and the latest orbit ID, with the latest solution's data arc in days where it was read. For 2022 CE2, 1999 AO10 and 2017 WJ2 the stated nominal sits near one end of a wide range, so a small shift in stated sigma can still leave the range.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/neo_outcomes.csv holds 58 rows: 17 CONSISTENT, 15 BELOW, 12 CANNOT_TELL, 12 ABOVE.

## Files

- results/neo_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/neo_summary.csv: the same file flattened to one row per value, with its path.
- results/neo_outcomes.json and results/neo_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because JPL states no reuse licence for its Solar System Dynamics APIs, and the archived copies are served under the Internet Archive terms of use.

## Cite

Heuremen LLC, ATLAS Desk Packs, Zenodo, doi:10.5281/zenodo.24118626

https://doi.org/10.5281/zenodo.24118626

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
