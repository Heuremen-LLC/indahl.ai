# NEO Data Pack

Heuremen LLC · https://indahl.ai/neo

As of 2026-11-14T12:09:28Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated asteroid close-approach distances against the later record. The page states it in full at https://indahl.ai/neo.

## The ruler

One row is one object and one approach inside 0.05 au since 1 January 2024, taken from the earliest copy that shows it before the approach. An object is counted once in a cell. Inside means the whole 3-sigma range of the latest solution lies inside the range stated earlier. Farther and closer mean the whole latest range lies outside it. Judged on the later nominal distance alone, counting the rows that cross an edge, 512 of 528 are inside, which reads the same. This was added after the data. Cannot tell is never folded into either side. In the first row it holds 168 where the stated solution is still the latest one, 40 where the latest range crosses an edge of the stated range, 21 where the stated range is wider than 0.05 au, 1 where no current record of the approach was found. The interval is a 95% Wilson interval. Reading: above if the lower bound is over 99.7 percent, below if the upper bound is under it, consistent if the whole interval lies from 98 to 100 percent, otherwise cannot tell with the reason STRADDLES_EDGE. Fewer than 10 scored rows is cannot tell with the reason TOO_WIDE_TO_RESOLVE. For a row, a stated solution that is still the latest, no current record and an unreadable value are cannot tell with the reason NO_INTERVAL_FORMABLE, a stated range wider than 0.05 au is TOO_WIDE_TO_RESOLVE, and a latest range that crosses an edge is STRADDLES_EDGE. Edges are closed, so an interval end equal to 99.7 percent is neither above nor below it. No size that matters is named for these cells, so the check for an interval that holds both zero and a size that matters is not applied. Failed reads and the rest of the cannot tell rows, cell by cell: all leads: 5929 NOTHING_RETURNED. CANNOT_TELL 230 of 718 (169 NO_INTERVAL_FORMABLE, 40 STRADDLES_EDGE, 21 TOO_WIDE_TO_RESOLVE). 0 to 7 days: 8 NOTHING_RETURNED. CANNOT_TELL 54 of 257 (33 NO_INTERVAL_FORMABLE, 21 STRADDLES_EDGE). 8 to 30 days: 10 NOTHING_RETURNED. CANNOT_TELL 9 of 109 (4 NO_INTERVAL_FORMABLE, 5 STRADDLES_EDGE). more than 30 days: 5917 NOTHING_RETURNED. CANNOT_TELL 167 of 353 (132 NO_INTERVAL_FORMABLE, 14 STRADDLES_EDGE, 21 TOO_WIDE_TO_RESOLVE). At this sample size a cell can read consistent only if nearly every row is inside. It takes about 190 scored rows, all inside, for the lower bound to reach 98 percent. The interval treats rows as independent. Rows from one copy share one moment of JPL's data, so the interval can be too narrow. The shift is the move of the nominal distance divided by one sixth of the stated range. It describes the move and is not a test. In 11 of these 14 rows the nominal distance moved by less than 2,000 km. 11 of the 14 stated ranges were under 1,000 km wide. Each stated copy links to the archived response. Solution shows the orbit ID the range was stated from and the latest orbit ID, with the latest solution's data arc in days where it was read. For 2022 CE2, 1999 AO10 and 2017 WJ2 the stated nominal sits near one end of a wide range, so a small shift in stated sigma can still leave the range.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/neo_outcomes.csv holds 58 rows: 18 CONSISTENT, 15 BELOW, 12 ABOVE, 11 CANNOT_TELL.

## Files

- results/neo_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/neo_summary.csv: the same file flattened to one row per value, with its path.
- results/neo_outcomes.json and results/neo_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because JPL states no reuse licence for its Solar System Dynamics APIs, and the archived copies are served under the Internet Archive terms of use.

## Cite

Heuremen LLC, ATLAS Desk Packs, Zenodo, doi:10.5281/zenodo.24118626

https://doi.org/10.5281/zenodo.24118626

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
