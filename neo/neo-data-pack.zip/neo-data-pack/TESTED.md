# NEO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-14 08:57 UTC and checked against the live feed at https://indahl.ai/neo/live.json.

- holds: neo_summary.csv: 291 rows, one per value of the live feed (291)
- holds: neo_outcomes.csv: 58 rows, the live feed holds 58 results, outcome, n, lo and hi equal on every row
- holds: page headline "203 of 203": 203 is in the pack
- holds: page headline "203 of 203": 203 is in the pack

TESTED 2026-11-14 08:57 UTC: 4 checks, every one holds.
