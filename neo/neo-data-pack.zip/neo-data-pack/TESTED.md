# NEO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 05:39 UTC and checked against the live feed at https://indahl.ai/neo/live.json.

- holds: neo_summary.csv: 289 rows, one per value of the live feed (289)
- holds: neo_outcomes.csv: 58 rows, the live feed holds 58 results, outcome, n, lo and hi equal on every row
- holds: page headline "198 of 198": 198 is in the pack
- holds: page headline "198 of 198": 198 is in the pack

TESTED 2026-11-13 05:39 UTC: 4 checks, every one holds.
