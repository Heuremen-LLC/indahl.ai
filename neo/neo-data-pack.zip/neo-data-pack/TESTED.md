# NEO Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 20:59 UTC and checked against the live feed at https://indahl.ai/neo/live.json.

- holds: neo_summary.csv: 290 rows, one per value of the live feed (290)
- holds: neo_outcomes.csv: 58 rows, the live feed holds 58 results, outcome, n, lo and hi equal on every row
- holds: page headline "202 of 202": 202 is in the pack
- holds: page headline "202 of 202": 202 is in the pack

TESTED 2026-11-13 20:59 UTC: 4 checks, every one holds.
