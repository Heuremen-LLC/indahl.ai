# RANK Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-12 06:37 UTC, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| US News & World Report education rankings (read in a browser, not redistributed) | https://www.usnews.com/education | US News terms, no redistribution | 2026-11-12 06:37 UTC |
| NJ School Performance Reports and NJSLA results files | https://www.nj.gov/education/sprreports/ | State of New Jersey public records | 2026-11-12 06:37 UTC |
| NCES Common Core of Data and IPEDS (via the Urban Institute Education Data API) | https://educationdata.urban.org/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-12 06:37 UTC |
| ABA Standard 509 and bar passage disclosures | https://www.abarequireddisclosures.org/ | ABA required disclosures, public | 2026-11-12 06:37 UTC |
| College Common Data Sets, state report cards | https://indahl.ai/rank | each publisher's own terms, figures cited only | 2026-11-12 06:37 UTC |
| Business school class profiles and employment reports, engineering and education school fact pages | https://indahl.ai/rank | each school's own terms, figures cited only | 2026-11-12 06:37 UTC |
| AAMC FACTS tables A-1 and B-1.2 | https://www.aamc.org/data-reports/students-residents/report/facts | AAMC terms, figures cited only | 2026-11-12 06:37 UTC |
| NIH RePORTER API | https://api.reporter.nih.gov/ | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-12 06:37 UTC |
| NSF NCSES HERD Survey FY2024 data tables | https://ncses.nsf.gov/surveys/higher-education-research-development/2024 | U.S. government work, public domain (17 U.S.C. 105) | 2026-11-12 06:37 UTC |
