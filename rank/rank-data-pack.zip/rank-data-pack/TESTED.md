# RANK Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 16:17 UTC and checked against the live feed at https://indahl.ai/rank/live.json.

- holds: rank_summary.csv: 1663 rows, one per value of the live feed (1663)
- holds: rank_outcomes.csv: 787 rows, the live feed holds 787 results, outcome, n, lo and hi equal on every row

TESTED 2026-11-12 16:17 UTC: 2 checks, every one holds.
