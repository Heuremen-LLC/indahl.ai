# RANK Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 18:28 UTC and checked against the live feed at https://indahl.ai/rank/live.json.

- holds: rank_summary.csv: 1041 rows, one per value of the live feed (1041)
- holds: rank_outcomes.csv: 489 rows, the live feed holds 489 results, outcome, n, lo and hi equal on every row

TESTED 2026-11-10 18:28 UTC: 2 checks, every one holds.
