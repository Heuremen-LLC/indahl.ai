# Example tables

The tables measured minutes before our 31 October 2026 run (fields k4 and k8: degrees per readout from blocks of 4 and 8 readouts, cohD8: coherence of the idle comparison). They are in the study's format and cannot be used with the kit's apply command. They come from the study's public files (https://github.com/Heuremen-LLC/indahl.ai/tree/main/code/readout-correction/run/data) and show the size of the turn we saw. They are not a table for your run.
