# Hardware check

Two preregistered fires on ibm_kingston, 2 November 2026: fire1_v1.0 (failed: the correction gave back 0.264 of the turn) and fire2_v1.1 (passed: 1.012). Each folder holds its plan, its results and its README. Raw arrays, circuits and calibration records: https://github.com/Heuremen-LLC/indahl.ai/tree/main/code/darkwave-kit/hardware-check
