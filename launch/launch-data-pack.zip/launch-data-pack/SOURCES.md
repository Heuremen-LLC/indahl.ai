# LAUNCH Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 13 Nov 2026 21:05, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| Launch Library 2 | https://thespacedevs.com/llapi | The Space Devs terms, no data licence stated | 13 Nov 2026 21:05 |
