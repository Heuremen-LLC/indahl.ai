# LAUNCH Data Pack

Heuremen LLC · https://indahl.ai/launch

As of 13 Nov 2026 19:01, the time stamped on the desk's feed when this pack was built.

## The question

Stated launch time against the time it flew. The page states it in full at https://indahl.ai/launch.

## The ruler

Slip is the absolute difference in hours. Above: the lower end of the 95 percent interval of the share that slipped by more than 24 hours is at or above 10 percent. Consistent: the whole interval lies below 10 percent. Cannot tell comes with a reason beside it. TOO_WIDE_TO_RESOLVE means fewer than 30 launches are scored or the interval holds both zero and 25 percent, which is the size that matters. STRADDLES_EDGE means the interval overlaps the 10 percent edge. NO_INTERVAL_FORMABLE means no interval can be formed. The same rule applies at every lead. It moved to Standards 2.0 on 12 November 2026 by a plan addendum, and earlier readings stand under the rule they named. REQ-13 beside each row gives the list reads that returned nothing and the share of cannot tell by reason. Data: Launch Library 2.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/launch_outcomes.csv holds 2 rows: 2 CANNOT_TELL.

## Files

- results/launch_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/launch_summary.csv: the same file flattened to one row per value, with its path.
- results/launch_outcomes.json and results/launch_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because The Space Devs state no data licence for Launch Library 2.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
