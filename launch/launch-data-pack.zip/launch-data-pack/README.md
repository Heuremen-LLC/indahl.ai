# LAUNCH Data Pack

Heuremen LLC · https://indahl.ai/launch

As of 10 Nov 2026 13:33, the time stamped on the desk's feed when this pack was built.

## The question

Stated launch time against the time it flew. The page states it in full at https://indahl.ai/launch.

## The ruler

Slip is the absolute difference in hours. Above: the share of launches that slipped by more than 24 hours at 7 days lead has a lower bound above 25 percent. Consistent: the upper bound is below 10 percent. Cannot tell: neither, or fewer than 30 scored launches. Thresholds were fixed before the first snapshot. Data: Launch Library 2.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/launch_outcomes.csv holds 2 rows: 2 CANNOT_TELL.

## Files

- results/launch_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/launch_summary.csv: the same file flattened to one row per value, with its path.
- results/launch_outcomes.json and results/launch_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because The Space Devs state no data licence for Launch Library 2.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
