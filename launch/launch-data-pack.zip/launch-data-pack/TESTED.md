# LAUNCH Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-11 21:42 UTC and checked against the live feed at https://indahl.ai/launch/live.json.

- holds: launch_summary.csv: 32 rows, one per value of the live feed (32)
- holds: launch_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: page headline "10": 10 is in the pack

TESTED 2026-11-11 21:42 UTC: 3 checks, every one holds.
