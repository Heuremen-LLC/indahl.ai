# LAUNCH Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-14 00:04 UTC and checked against the live feed at https://indahl.ai/launch/live.json.

- holds: launch_summary.csv: 42 rows, one per value of the live feed (42)
- holds: launch_outcomes.csv: 2 rows, the live feed holds 2 results, outcome, n, lo and hi equal on every row
- holds: page headline "11": 11 is in the pack

TESTED 2026-11-14 00:04 UTC: 3 checks, every one holds.
