# SEASONAL Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-13 20:59 UTC and checked against the live feed at https://indahl.ai/seasonal/live.json.

- holds: seasonal_summary.csv: 737 rows, one per value of the live feed (737)
- holds: seasonal_outcomes.csv: 50 rows, the live feed holds 50 results, outcome, n, lo and hi equal on every row
- holds: seasonal_summary.json: byte for byte the live feed (sha256 dcb0d5b5b59e8170)
- holds: page headline "60.1%": 60.1% is in the pack

TESTED 2026-11-13 20:59 UTC: 4 checks, every one holds.
