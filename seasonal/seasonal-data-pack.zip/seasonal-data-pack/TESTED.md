# SEASONAL Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-10 16:38 UTC and checked against the live feed at https://indahl.ai/seasonal/live.json.

- holds: seasonal_summary.csv: 655 rows, one per value of the live feed (655)
- holds: seasonal_outcomes.csv: 50 rows, the live feed holds 50 results, outcome, n, lo and hi equal on every row
- holds: seasonal_summary.json: byte for byte the live feed (sha256 3252ba09e3390d5b)
- holds: page headline "60.1%": 60.1% is in the pack

TESTED 2026-11-10 16:38 UTC: 4 checks, every one holds.
