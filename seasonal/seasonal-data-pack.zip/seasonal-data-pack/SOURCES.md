# SEASONAL Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 2026-11-14T06:19:22Z, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| NOAA Climate Prediction Center 3-month outlook verification files | https://www.cpc.ncep.noaa.gov/products/predictions/long_range/tools/briefing/seas_veri.grid.php | NOAA/NWS, public domain, https://www.weather.gov/disclaimer | 2026-11-14T06:19:22Z |
