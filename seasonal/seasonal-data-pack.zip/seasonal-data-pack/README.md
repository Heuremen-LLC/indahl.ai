# SEASONAL Data Pack

Heuremen LLC · https://indahl.ai/seasonal

As of 2026-11-11T20:53:40Z, the time stamped on the desk's feed when this pack was built.

## The question

Stated seasonal outlook chances against what was observed. The page states it in full at https://indahl.ai/seasonal.

## The ruler

One row is one season, one grid cell and one category, with the chance stated for that category. Rows are not independent. Every cell in a season shares one weather pattern, and neighbouring 3-month seasons share two of their months. So the interval is a moving-block bootstrap over seasons, in blocks of 12 consecutive seasons, 2,000 draws, and it is much wider than one that treats cells as independent. Reading: above if the whole interval is over the mean stated chance (the category happened more often than stated), below if it is under, consistent if the mean stated chance is inside an interval no wider than 10 points, otherwise cannot tell. A cell needs 30 rows and 24 seasons. Near normal is 100 minus the stated chances of above and below. The bin from 31 to 35 percent holds the equal-chances rows. The observed categories come from CPC’s own verification files. CPC’s verification tutorial says “The observation categories are determined by using the climatology data from 1981-2010 as the reference period.” Over all cells and seasons the observed temperature category was above normal 51.6 percent of the time, near 28.6 percent and below 19.9 percent. For precipitation it was 35.2, 31.4 and 33.4 percent. Cells are not weighted by area. Described and not scored: in the temperature leaning cell, 28,312 rows stated above normal at a mean of 48.7 percent and above normal was observed in 62.1 percent, and 2,394 rows stated below normal at a mean of 43.6 percent and below normal was observed in 37.6 percent. Reading: consistent if the interval of the mean difference lies inside minus 2 to plus 2 points, above or below if it lies wholly beyond that, otherwise cannot tell. For precipitation the first score covers 374 of 380 seasons. In the other 6 every cell was equal chances. CPC lists no first score for them and an all score of 0, and ours is the same. The largest gap is 1.26 points, in JFM 2021 for precipitation, where 4 cells with a category that is not a whole number were left out. This check shows that our reading of the archive pairs each outlook with the right season. It does not test the chances themselves.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/seasonal_outcomes.csv holds 50 rows: 23 CANNOT_TELL, 13 CONSISTENT, 8 ABOVE, 6 BELOW.

## Files

- results/seasonal_summary.json: the feed as served at https://indahl.ai/seasonal/live.json when this pack was built.
- results/seasonal_summary.csv: the same file flattened to one row per value, with its path.
- results/seasonal_outcomes.json and results/seasonal_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

The sources are public domain, openly licensed or our own measurements, so the pack carries the feed as served, with credit to each source in NOTICE.txt.

## Cite

Heuremen LLC, HERMES Desk Packs, Zenodo, doi:10.5281/zenodo.24110659

https://doi.org/10.5281/zenodo.24110659

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
