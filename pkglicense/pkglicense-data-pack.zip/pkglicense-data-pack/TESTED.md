# PKGLICENSE Data Pack: tested

Every CSV in this pack was opened again with a CSV reader on 2026-11-12 22:47 UTC and checked against the live feed at https://indahl.ai/pkglicense/live.json.

- holds: pkglicense_summary.csv: 48 rows, one per value of the live feed (48)
- holds: pkglicense_outcomes.csv: 1 rows, the live feed holds 1 results, outcome, n, lo and hi equal on every row
- holds: page headline "7 of 704": 7 is in the pack
- holds: page headline "7 of 704": 704 is in the pack

TESTED 2026-11-12 22:47 UTC: 4 checks, every one holds.
