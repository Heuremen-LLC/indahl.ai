# PKGLICENSE Data Pack: sources

Each source is read by the desk on its own schedule. The feed in this pack was read at 14 Nov 2026 11:34, and that is the pull date for every source below.

| Source | Address | Licence or terms | Pulled |
|---|---|---|---|
| PyPI JSON API | https://docs.pypi.org/api/json/ | PyPI terms of service | 14 Nov 2026 11:34 |
| Top PyPI Packages | https://hugovk.github.io/top-pypi-packages/ | public list | 14 Nov 2026 11:34 |
| GitHub GraphQL API licenseInfo | https://docs.github.com/en/graphql | GitHub terms of service | 14 Nov 2026 11:34 |
