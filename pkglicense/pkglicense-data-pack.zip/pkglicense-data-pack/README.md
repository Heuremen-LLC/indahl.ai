# PKGLICENSE Data Pack

Heuremen LLC · https://indahl.ai/pkglicense

As of 13 Nov 2026 23:06, the time stamped on the desk's feed when this pack was built.

## The question

Package licenses against repository licenses. The page states it in full at https://indahl.ai/pkglicense.

## The ruler

Agree: the stated license and the repository's license fall in the same family (MIT, Apache-2.0, BSD, GPL and so on, and GPL with no version agrees with either). Disagree: both are named and the families differ. Above: the share that disagree has a lower bound above 10 percent. Consistent: the upper bound is below 5 percent. Source: the PyPI JSON API, GitHub, and the public list of most downloaded projects.

## Four outcomes

ABOVE, BELOW, CONSISTENT and CANNOT_TELL are the four outcomes. A row reads CANNOT_TELL when its interval does not settle the question. Where the page uses another word, such as NOTHING_RETURNED, it is kept as printed. The lo and hi columns are the interval bounds the desk prints with each result, and the page names the method.

results/pkglicense_outcomes.csv holds 1 row: 1 CONSISTENT.

## Files

- results/pkglicense_summary.json: our counts, outcomes, intervals and labels from the feed, with every other value left out.
- results/pkglicense_summary.csv: the same file flattened to one row per value, with its path.
- results/pkglicense_outcomes.json and results/pkglicense_outcomes.csv: every result in it that carries an outcome or an interval, one row each, with path, label, outcome, n, of, share, lo and hi columns.
- SOURCES.md: every source with its address, licence and pull date.
- LICENSE.txt and NOTICE.txt: the terms of each part and the credit lines.
- CITATION.cff: how to cite this pack.
- TESTED.md: what was checked against the live page and feed before this pack was placed.
- SHA256SUMS.txt: the sha256 of every other file in the pack.

## Licence

This pack carries only our derived results (counts, outcomes and intervals) and links to the sources, because PyPI and GitHub metadata are under their terms of service and not an open licence.

## Cite

Heuremen LLC, IRIS Desk Packs, Zenodo, doi:10.5281/zenodo.24110664

https://doi.org/10.5281/zenodo.24110664

This pack is one file of that Zenodo record, which holds the packs of the desks listed there. That DOI always points to the newest version on Zenodo. Each version there also has its own DOI.
